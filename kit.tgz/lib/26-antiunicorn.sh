#!/bin/sh
# 26-antiunicorn.sh — их detect_kill_unicorn, обобщённый.
# Убивает процессы, чей cwd лежит в чужих dot-каталогах, сносит деревья
# «CRON jobs», чистит IOC-строки из crontab и файлов ~/.claude.

KF_UNICORN_IOC='95\.85\.237\.226|193\.41\.68\.194|95\.85\.237\.149|2\.26\.99\.68|210\.195\.19\.39|apt-update\.com|joker\.aec944b68370194a50|\.claude|CRON jobs|unicorn'

kf_detect_kill_unicorn() {
  _u_uid=$(kf_uid)
  _u_home="${HOME:-/tmp}"
  _u_hits=""
  _u_tree=""

  # 1. процессы, чей cwd в чужом dot-каталоге
  for _u_p in /proc/[0-9]*; do
    _u_pid="${_u_p##*/}"
    [ "$_u_pid" = "$$" ] && continue
    [ "$(awk '/^Uid:/{print $2}' "$_u_p/status" 2>/dev/null)" = "$_u_uid" ] || continue
    _u_cwd=$(readlink "$_u_p/cwd" 2>/dev/null)
    case "$_u_cwd" in
      "$_u_home"/.claude|"$_u_home"/.claude/*|"$_u_home"/.unicorn|*/\.cache/[a-z]*/unicorn)
        kf_exempt "$(tr '\0' ' ' < "$_u_p/cmdline" 2>/dev/null)" && continue
        _u_hits="$_u_hits $_u_pid" ;;
    esac
  done

  # 2. корни деревьев «CRON jobs»
  for _u_p in /proc/[0-9]*; do
    _u_pid="${_u_p##*/}"
    [ "$_u_pid" = "$$" ] && continue
    [ "$(awk '/^Uid:/{print $2}' "$_u_p/status" 2>/dev/null)" = "$_u_uid" ] || continue
    _u_cmd=$(tr '\0' ' ' < "$_u_p/cmdline" 2>/dev/null)
    case "$_u_cmd" in
      *CRON\ jobs*) _u_tree="$_u_tree $_u_pid" ;;
    esac
  done

  # 3. потомки этих деревьев (5 кругов, как у них)
  for _u_r in 1 2 3 4 5; do
    for _u_p in /proc/[0-9]*; do
      _u_pid="${_u_p##*/}"
      [ "$_u_pid" = "$$" ] && continue
      [ "$(awk '/^Uid:/{print $2}' "$_u_p/status" 2>/dev/null)" = "$_u_uid" ] || continue
      _u_pp=$(awk '{print $4}' "$_u_p/stat" 2>/dev/null)
      case " $_u_tree " in
        *" $_u_pp "*) case " $_u_tree " in *" $_u_pid "*) ;; *) _u_tree="$_u_tree $_u_pid" ;; esac ;;
      esac
    done
  done

  for _u_pid in $_u_hits $_u_tree; do kill -TERM "$_u_pid" 2>/dev/null; done
  sleep 1
  for _u_pid in $_u_hits $_u_tree; do
    kill -0 "$_u_pid" 2>/dev/null && kill -KILL "$_u_pid" 2>/dev/null
  done
  [ -n "$_u_hits$_u_tree" ] && kf_log "unicorn: снято$_u_hits$_u_tree"

  # 4. IOC из crontab
  if command -v crontab >/dev/null 2>&1; then
    _u_ct="${TMPDIR:-/tmp}/.ufcron.$$"
    if crontab -l 2>/dev/null > "$_u_ct"; then
      if grep -Eq "$KF_UNICORN_IOC" "$_u_ct" 2>/dev/null; then
        grep -vE "$KF_UNICORN_IOC" "$_u_ct" 2>/dev/null | crontab - 2>/dev/null
        kf_log "unicorn: crontab вычищен"
      fi
    fi
    rm -f "$_u_ct" 2>/dev/null
  fi

  # 5. их файлы в ~/.claude
  for _u_f in "$_u_home/.claude/unicorn" "$_u_home/.claude/CRON" "$_u_home/.claude/jobs" \
              "$_u_home/.claude/pwb" "$_u_home/.claude/config.json"; do
    [ -O "$_u_f" ] || continue
    rm -f "$_u_f" 2>/dev/null && kf_log "unicorn: удалён $_u_f"
  done
  return 0
}
